import 'package:flutter/material.dart';
import '../models/friend.dart';
import '../models/user_profile.dart';
import 'chat_screen.dart';
import 'topology_screen.dart';

class HomeScreen extends StatefulWidget {
  final UserProfile user;

  const HomeScreen({Key? key, required this.user}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late List<Friend> _friends;

  @override
  void initState() {
    super.initState();
    _friends = [
      Friend(
        id: 'friend_karim',
        name: 'Karim Z.',
        phone: '+212 6 12 34 56 78',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        status: FriendStatus.nearbyBle,
        signalRssi: -42,
        distanceMeters: 3.5,
        lastSeen: 'À l\'instant (BLE)',
        publicKey: 'BEN-A9F438B0182C3D4E',
        batteryLevel: 91,
        deviceModel: 'Samsung Galaxy S23 Ultra',
        isRelayNode: true,
      ),
      Friend(
        id: 'friend_amina',
        name: 'Amina D.',
        phone: '+212 6 98 76 54 32',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
        status: FriendStatus.outOfRangeRelay,
        signalRssi: -78,
        distanceMeters: 45.0,
        lastSeen: 'Relais via Karim',
        publicKey: 'BEN-77CD129845FE6A31',
        batteryLevel: 68,
        deviceModel: 'Xiaomi 13T Pro',
        isRelayNode: true,
      ),
      Friend(
        id: 'friend_youssef',
        name: 'Youssef B.',
        phone: '+212 6 55 44 33 22',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
        status: FriendStatus.nearbyWifiDirect,
        signalRssi: -35,
        distanceMeters: 8.2,
        lastSeen: 'Connecté P2P',
        publicKey: 'BEN-8841B9F0014D89E3',
        batteryLevel: 84,
        deviceModel: 'Google Pixel 8',
        isRelayNode: true,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFFD4AF37)),
              ),
              child: const Text("👑", style: TextStyle(fontSize: 16)),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  "BENSALMAN",
                  style: TextStyle(
                    color: Color(0xFFD4AF37),
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                    fontSize: 16,
                  ),
                ),
                Text(
                  "Réseau Maillé Sans Internet",
                  style: TextStyle(color: Colors.white54, fontSize: 10),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share, color: Color(0xFFD4AF37)),
            tooltip: "Topologie Maillée",
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const TopologyScreen()));
            },
          ),
          IconButton(
            icon: const Icon(Icons.qr_code_scanner, color: Color(0xFFD4AF37)),
            tooltip: "Ajouter un ami (Pairing)",
            onPressed: () {},
          ),
        ],
      ),
      body: ListView.separated(
        itemCount: _friends.length,
        separatorBuilder: (_, __) => const Divider(color: Color(0xFF1E1E1E), height: 1),
        itemBuilder: (context, index) {
          final friend = _friends[index];
          return ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: Stack(
              children: [
                CircleAvatar(
                  backgroundImage: NetworkImage(friend.avatar),
                  radius: 24,
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: friend.status == FriendStatus.outOfRangeRelay ? const Color(0xFFD4AF37) : Colors.emerald,
                      shape: BoxShape.circle,
                      border: Border.all(color: const Color(0xFF141414), width: 2),
                    ),
                  ),
                ),
              ],
            ),
            title: Text(
              friend.name,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
            ),
            subtitle: Row(
              children: [
                Icon(
                  friend.status == FriendStatus.outOfRangeRelay ? Icons.hub_outlined : Icons.bluetooth,
                  size: 13,
                  color: friend.status == FriendStatus.outOfRangeRelay ? const Color(0xFFD4AF37) : Colors.blueAccent,
                ),
                const SizedBox(width: 4),
                Text(
                  friend.lastSeen,
                  style: const TextStyle(color: Colors.white54, fontSize: 12),
                ),
              ],
            ),
            trailing: Text(
              "${friend.distanceMeters.toStringAsFixed(1)}m",
              style: const TextStyle(color: Color(0xFFD4AF37), fontSize: 12, fontWeight: FontWeight.bold),
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ChatScreen(friend: friend, currentUser: widget.user),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
