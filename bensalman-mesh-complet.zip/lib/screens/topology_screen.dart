import 'package:flutter/material.dart';

class TopologyScreen extends StatelessWidget {
  const TopologyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        title: const Text("Topologie Maillée (Mesh)", style: TextStyle(color: Color(0xFFD4AF37), fontWeight: FontWeight.bold)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFFD4AF37)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF141414),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFD4AF37).withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Text("État du Maillage Local", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      Chip(
                        label: Text("Opérationnel", style: TextStyle(color: Colors.black, fontSize: 11, fontWeight: FontWeight.bold)),
                        backgroundColor: Color(0xFFD4AF37),
                      ),
                    ],
                  ),
                  const Divider(color: Color(0xFF262626), height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildMetric("3", "Nœuds Proches"),
                      _buildMetric("2.4 GHz", "Bande Radio"),
                      _buildMetric("< 18ms", "Latence BLE"),
                      _buildMetric("0%", "Perte Paquets"),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text("Schéma de Relais Multi-Sauts", style: TextStyle(color: Color(0xFFD4AF37), fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF141414),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFF262626)),
              ),
              child: Column(
                children: [
                  _buildNodeItem("Salman Bah (Vous)", "Nœud Source • Tx 0 dBm", Icons.phone_android, Colors.emerald),
                  const Icon(Icons.arrow_downward, color: Color(0xFFD4AF37)),
                  _buildNodeItem("Karim Z.", "Nœud Relais • BLE Direct + Wi-Fi Direct", Icons.hub, const Color(0xFFD4AF37)),
                  const Icon(Icons.arrow_downward, color: Color(0xFFD4AF37)),
                  _buildNodeItem("Amina D.", "Nœud Destination • Hors de portée directe (45m)", Icons.person, Colors.blueAccent),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetric(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(color: Color(0xFFD4AF37), fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(color: Colors.white54, fontSize: 10)),
      ],
    );
  }

  Widget _buildNodeItem(String title, String subtitle, IconData icon, Color iconColor) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: iconColor.withOpacity(0.15),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
