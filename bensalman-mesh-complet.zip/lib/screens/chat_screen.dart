import 'package:flutter/material.dart';
import '../models/friend.dart';
import '../models/message.dart';
import '../models/user_profile.dart';
import '../services/mesh_service.dart';
import '../services/audio_service.dart';

class ChatScreen extends StatefulWidget {
  final Friend friend;
  final UserProfile currentUser;

  const ChatScreen({
    Key? key,
    required this.friend,
    required this.currentUser,
  }) : super(key: key);

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<MeshMessage> _messages = [];
  bool _isVoiceRecording = false;

  @override
  void initState() {
    super.initState();
    _loadSampleHistory();
  }

  void _loadSampleHistory() {
    _messages.addAll([
      MeshMessage(
        id: 'msg_1',
        chatId: widget.friend.id,
        senderId: widget.friend.id,
        senderName: widget.friend.name,
        recipientId: widget.currentUser.id,
        type: MessageType.text,
        content: "Salam ! Tu me reçois en Bluetooth direct ?",
        encryptedPayload: "ENC:38fa72:dGVzdA==",
        timestamp: "10:14",
        deliveryStatus: DeliveryStatus.read,
        transport: TransportMethod.ble,
        hopsTrace: [
          HopTrace(nodeId: widget.friend.id, nodeName: widget.friend.name, method: 'BLE', timestamp: '10:14'),
          HopTrace(nodeId: widget.currentUser.id, nodeName: widget.currentUser.name, method: 'BLE', timestamp: '10:14'),
        ],
      ),
      MeshMessage(
        id: 'msg_2',
        chatId: widget.friend.id,
        senderId: widget.currentUser.id,
        senderName: widget.currentUser.name,
        recipientId: widget.friend.id,
        type: MessageType.text,
        content: "Parfaitement ! Aucune connexion Internet ni carte SIM requise.",
        encryptedPayload: "ENC:88ab12:c2FsYW0=",
        timestamp: "10:15",
        deliveryStatus: DeliveryStatus.read,
        transport: TransportMethod.ble,
        hopsTrace: [
          HopTrace(nodeId: widget.currentUser.id, nodeName: widget.currentUser.name, method: 'BLE', timestamp: '10:15'),
          HopTrace(nodeId: widget.friend.id, nodeName: widget.friend.name, method: 'BLE', timestamp: '10:15'),
        ],
      ),
    ]);
  }

  void _sendMessage(String text) {
    if (text.trim().isEmpty) return;
    final now = DateTime.now();
    final timeStr = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";

    final newMsg = MeshMessage(
      id: "msg_${now.millisecondsSinceEpoch}",
      chatId: widget.friend.id,
      senderId: widget.currentUser.id,
      senderName: widget.currentUser.name,
      recipientId: widget.friend.id,
      type: MessageType.text,
      content: text,
      encryptedPayload: "ENC:simulated:${text.hashCode}",
      timestamp: timeStr,
      deliveryStatus: widget.friend.status == FriendStatus.outOfRangeRelay ? DeliveryStatus.relayed : DeliveryStatus.delivered,
      transport: widget.friend.status == FriendStatus.outOfRangeRelay ? TransportMethod.meshRelay : TransportMethod.ble,
      hopsTrace: [
        HopTrace(nodeId: widget.currentUser.id, nodeName: widget.currentUser.name, method: 'BLE', timestamp: timeStr),
        HopTrace(nodeId: widget.friend.id, nodeName: widget.friend.name, method: 'BLE', timestamp: timeStr),
      ],
    );

    setState(() {
      _messages.add(newMsg);
      _textController.clear();
    });

    MeshService().sendMeshMessage(
      sender: widget.currentUser,
      recipient: widget.friend,
      rawContent: text,
      type: MessageType.text,
    );

    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        elevation: 1,
        titleSpacing: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFFD4AF37)),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Row(
          children: [
            CircleAvatar(
              backgroundImage: NetworkImage(widget.friend.avatar),
              radius: 18,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.friend.name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                        width: 7,
                        height: 7,
                        decoration: BoxDecoration(
                          color: widget.friend.status == FriendStatus.outOfRangeRelay
                              ? const Color(0xFFD4AF37)
                              : Colors.emerald,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 5),
                      Text(
                        widget.friend.status == FriendStatus.outOfRangeRelay
                            ? "Relais Mesh (Hors portée)"
                            : "BLE Direct (~${widget.friend.distanceMeters.toStringAsFixed(1)}m)",
                        style: const TextStyle(color: Color(0xFF999999), fontSize: 11),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.hub_outlined, color: Color(0xFFD4AF37)),
            tooltip: "Trajet des nœuds relais",
            onPressed: () => _showRouteModal(context),
          ),
          IconButton(
            icon: const Icon(Icons.shield_outlined, color: Color(0xFFD4AF37)),
            tooltip: "Clé chiffrée E2EE",
            onPressed: () => _showEncryptionModal(context),
          ),
        ],
      ),
      body: Column(
        children: [
          // Bannière de statut sécurité
          Container(
            padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
            color: const Color(0xFF1B180A),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.lock_clock_outlined, size: 14, color: Color(0xFFD4AF37)),
                SizedBox(width: 6),
                Text(
                  "Zero Internet • Chiffrement de bout en bout BENSALMAN",
                  style: TextStyle(color: Color(0xFFD4AF37), fontSize: 11, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),

          // Liste des messages
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(12),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages[index];
                final isMe = msg.senderId == widget.currentUser.id;
                return _buildMessageBubble(msg, isMe);
              },
            ),
          ),

          // Zone de saisie
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(MeshMessage msg, bool isMe) {
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: isMe ? const Color(0xFF2A230A) : const Color(0xFF1C1C1C),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: isMe ? const Radius.circular(16) : Radius.zero,
            bottomRight: isMe ? Radius.zero : const Radius.circular(16),
          ),
          border: Border.all(
            color: isMe ? const Color(0xFFD4AF37).withOpacity(0.4) : const Color(0xFF2D2D2D),
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              msg.content,
              style: const TextStyle(color: Colors.white, fontSize: 14),
            ),
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  msg.timestamp,
                  style: const TextStyle(color: Colors.white38, fontSize: 10),
                ),
                const SizedBox(width: 4),
                if (isMe)
                  Icon(
                    msg.deliveryStatus == DeliveryStatus.read ? Icons.done_all : Icons.done,
                    size: 14,
                    color: msg.deliveryStatus == DeliveryStatus.read ? const Color(0xFFD4AF37) : Colors.white38,
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      color: const Color(0xFF141414),
      child: SafeArea(
        child: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.attach_file, color: Color(0xFF888888)),
              onPressed: () {},
            ),
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: const Color(0xFF1F1F1F),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: const Color(0xFF333333)),
                ),
                child: TextField(
                  controller: _textController,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: const InputDecoration(
                    hintText: "Message offline...",
                    hintStyle: TextStyle(color: Colors.white38),
                    border: InputBorder.none,
                  ),
                  onSubmitted: _sendMessage,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [Color(0xFFD4AF37), Color(0xFFAA820A)]),
              ),
              child: IconButton(
                icon: const Icon(Icons.send, color: Colors.black, size: 20),
                onPressed: () => _sendMessage(_textController.text),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showRouteModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF141414),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Routage Maillé A -> B -> C",
              style: TextStyle(color: Color(0xFFD4AF37), fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            const Text(
              "Les paquets BLE sont relayés de proche en proche par les téléphones compatibles sans jamais révéler les données grâce au chiffrement E2EE.",
              style: TextStyle(color: Colors.white70, fontSize: 13),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFD4AF37)),
              onPressed: () => Navigator.pop(context),
              child: const Text("Fermer", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  void _showEncryptionModal(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF181818),
        title: const Text("Sécurité Cryptographique", style: TextStyle(color: Color(0xFFD4AF37))),
        content: Text(
          "Clé Publique du Contact:\n${widget.friend.publicKey}\n\nChiffrement: AES-256-GCM + Curve25519\nZéro serveur intermédiaire.",
          style: const TextStyle(color: Colors.white70, fontSize: 12, fontFamily: 'monospace'),
        ),
        actions: [
          TextButton(
            child: const Text("Fermer", style: TextStyle(color: Color(0xFFD4AF37))),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }
}
