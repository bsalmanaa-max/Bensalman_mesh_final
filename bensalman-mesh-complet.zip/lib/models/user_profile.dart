class UserProfile {
  final String id;
  final String name;
  final String phone;
  final String avatar;
  final String publicKey;
  final String privateKey;
  final String deviceBleMac;
  final int batteryLevel;
  final bool isMeshRelayEnabled;
  final bool isBleAdvertising;
  final bool isWifiDirectEnabled;

  UserProfile({
    required this.id,
    required this.name,
    required this.phone,
    required this.avatar,
    required this.publicKey,
    required this.privateKey,
    required this.deviceBleMac,
    this.batteryLevel = 94,
    this.isMeshRelayEnabled = true,
    this.isBleAdvertising = true,
    this.isWifiDirectEnabled = true,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'phone': phone,
    'avatar': avatar,
    'publicKey': publicKey,
    'privateKey': privateKey,
    'deviceBleMac': deviceBleMac,
    'batteryLevel': batteryLevel,
    'isMeshRelayEnabled': isMeshRelayEnabled,
    'isBleAdvertising': isBleAdvertising,
    'isWifiDirectEnabled': isWifiDirectEnabled,
  };

  factory UserProfile.fromMap(Map<String, dynamic> map) => UserProfile(
    id: map['id'] ?? '',
    name: map['name'] ?? '',
    phone: map['phone'] ?? '',
    avatar: map['avatar'] ?? '',
    publicKey: map['publicKey'] ?? '',
    privateKey: map['privateKey'] ?? '',
    deviceBleMac: map['deviceBleMac'] ?? '',
    batteryLevel: map['batteryLevel'] ?? 94,
    isMeshRelayEnabled: map['isMeshRelayEnabled'] ?? true,
    isBleAdvertising: map['isBleAdvertising'] ?? true,
    isWifiDirectEnabled: map['isWifiDirectEnabled'] ?? true,
  );
}
