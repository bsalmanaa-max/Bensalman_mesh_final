enum FriendStatus { nearbyBle, nearbyWifiDirect, outOfRangeRelay, offline }

class Friend {
  final String id;
  final String name;
  final String phone;
  final String avatar;
  FriendStatus status;
  final int signalRssi; // e.g. -45 dBm
  final double distanceMeters;
  final String lastSeen;
  final String publicKey;
  final int batteryLevel;
  final String deviceModel;
  final bool isRelayNode;

  Friend({
    required this.id,
    required this.name,
    required this.phone,
    required this.avatar,
    required this.status,
    required this.signalRssi,
    required this.distanceMeters,
    required this.lastSeen,
    required this.publicKey,
    required this.batteryLevel,
    required this.deviceModel,
    this.isRelayNode = true,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'phone': phone,
    'avatar': avatar,
    'status': status.name,
    'signalRssi': signalRssi,
    'distanceMeters': distanceMeters,
    'lastSeen': lastSeen,
    'publicKey': publicKey,
    'batteryLevel': batteryLevel,
    'deviceModel': deviceModel,
    'isRelayNode': isRelayNode,
  };

  factory Friend.fromMap(Map<String, dynamic> map) => Friend(
    id: map['id'] ?? '',
    name: map['name'] ?? '',
    phone: map['phone'] ?? '',
    avatar: map['avatar'] ?? '',
    status: FriendStatus.values.firstWhere(
      (e) => e.name == map['status'],
      orElse: () => FriendStatus.nearbyBle,
    ),
    signalRssi: map['signalRssi'] ?? -60,
    distanceMeters: (map['distanceMeters'] as num?)?.toDouble() ?? 5.0,
    lastSeen: map['lastSeen'] ?? 'À l\'instant',
    publicKey: map['publicKey'] ?? '',
    batteryLevel: map['batteryLevel'] ?? 80,
    deviceModel: map['deviceModel'] ?? 'Android Device',
    isRelayNode: map['isRelayNode'] ?? true,
  );
}
