import 'dart:convert';

enum MessageType { text, voice, image }
enum DeliveryStatus { sending, relayed, delivered, read, failed }
enum TransportMethod { ble, wifiDirect, meshRelay, internet }

class HopTrace {
  final String nodeId;
  final String nodeName;
  final String method;
  final String timestamp;

  HopTrace({
    required this.nodeId,
    required this.nodeName,
    required this.method,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
    'nodeId': nodeId,
    'nodeName': nodeName,
    'method': method,
    'timestamp': timestamp,
  };

  factory HopTrace.fromMap(Map<String, dynamic> map) => HopTrace(
    nodeId: map['nodeId'] ?? '',
    nodeName: map['nodeName'] ?? '',
    method: map['method'] ?? 'BLE',
    timestamp: map['timestamp'] ?? '',
  );
}

class MeshMessage {
  final String id;
  final String chatId;
  final String senderId;
  final String senderName;
  final String recipientId;
  final MessageType type;
  final String content;
  final String encryptedPayload;
  final String timestamp;
  DeliveryStatus deliveryStatus;
  TransportMethod transport;
  final List<HopTrace> hopsTrace;
  final int? voiceDurationSeconds;
  final String? imageCaption;
  int hopCount;
  final int ttl; // Time-to-live hops (default 7)

  MeshMessage({
    required this.id,
    required this.chatId,
    required this.senderId,
    required this.senderName,
    required this.recipientId,
    required this.type,
    required this.content,
    required this.encryptedPayload,
    required this.timestamp,
    this.deliveryStatus = DeliveryStatus.delivered,
    this.transport = TransportMethod.ble,
    required this.hopsTrace,
    this.voiceDurationSeconds,
    this.imageCaption,
    this.hopCount = 1,
    this.ttl = 7,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'chatId': chatId,
    'senderId': senderId,
    'senderName': senderName,
    'recipientId': recipientId,
    'type': type.name,
    'content': content,
    'encryptedPayload': encryptedPayload,
    'timestamp': timestamp,
    'deliveryStatus': deliveryStatus.name,
    'transport': transport.name,
    'hopsTrace': hopsTrace.map((h) => h.toMap()).toList(),
    'voiceDurationSeconds': voiceDurationSeconds,
    'imageCaption': imageCaption,
    'hopCount': hopCount,
    'ttl': ttl,
  };

  factory MeshMessage.fromMap(Map<String, dynamic> map) => MeshMessage(
    id: map['id'] ?? '',
    chatId: map['chatId'] ?? '',
    senderId: map['senderId'] ?? '',
    senderName: map['senderName'] ?? '',
    recipientId: map['recipientId'] ?? '',
    type: MessageType.values.firstWhere(
      (e) => e.name == map['type'],
      orElse: () => MessageType.text,
    ),
    content: map['content'] ?? '',
    encryptedPayload: map['encryptedPayload'] ?? '',
    timestamp: map['timestamp'] ?? '',
    deliveryStatus: DeliveryStatus.values.firstWhere(
      (e) => e.name == map['deliveryStatus'],
      orElse: () => DeliveryStatus.delivered,
    ),
    transport: TransportMethod.values.firstWhere(
      (e) => e.name == map['transport'],
      orElse: () => TransportMethod.ble,
    ),
    hopsTrace: (map['hopsTrace'] as List? ?? [])
        .map((h) => HopTrace.fromMap(h))
        .toList(),
    voiceDurationSeconds: map['voiceDurationSeconds'],
    imageCaption: map['imageCaption'],
    hopCount: map['hopCount'] ?? 1,
    ttl: map['ttl'] ?? 7,
  );

  String toJson() => jsonEncode(toMap());
  factory MeshMessage.fromJson(String str) => MeshMessage.fromMap(jsonDecode(str));
}
