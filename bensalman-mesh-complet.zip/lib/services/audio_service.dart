import 'dart:async';
import 'package:flutter/foundation.dart';

class AudioService extends ChangeNotifier {
  static final AudioService _instance = AudioService._internal();
  factory AudioService() => _instance;
  AudioService._internal();

  bool _isRecording = false;
  bool _isPlaying = false;
  int _recordDurationSeconds = 0;
  Timer? _timer;

  bool get isRecording => _isRecording;
  bool get isPlaying => _isPlaying;
  int get recordDurationSeconds => _recordDurationSeconds;

  void startRecording() {
    _isRecording = true;
    _recordDurationSeconds = 0;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _recordDurationSeconds++;
      notifyListeners();
    });
    notifyListeners();
  }

  Future<Map<String, dynamic>> stopRecording() async {
    _timer?.cancel();
    _isRecording = false;
    final duration = _recordDurationSeconds;
    notifyListeners();
    return {
      'durationSeconds': duration > 0 ? duration : 1,
      'audioData': 'base64_simulated_offline_opus_audio_payload',
    };
  }

  void playAudio(String audioId) {
    _isPlaying = true;
    notifyListeners();
    Future.delayed(const Duration(seconds: 4), () {
      _isPlaying = false;
      notifyListeners();
    });
  }
}
