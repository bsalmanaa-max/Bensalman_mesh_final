import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/message.dart';
import '../models/friend.dart';
import '../models/user_profile.dart';
import 'crypto_service.dart';

class MeshPacket {
  final String packetId;
  final String sourceNodeId;
  final String destinationNodeId;
  final int hopCount;
  final int ttl;
  final String encryptedPayload;
  final List<String> routedViaNodes;

  MeshPacket({
    required this.packetId,
    required this.sourceNodeId,
    required this.destinationNodeId,
    required this.hopCount,
    required this.ttl,
    required this.encryptedPayload,
    required this.routedViaNodes,
  });

  Map<String, dynamic> toMap() => {
    'pid': packetId,
    'src': sourceNodeId,
    'dst': destinationNodeId,
    'hops': hopCount,
    'ttl': ttl,
    'data': encryptedPayload,
    'route': routedViaNodes,
  };

  factory MeshPacket.fromMap(Map<String, dynamic> map) => MeshPacket(
    packetId: map['pid'] ?? '',
    sourceNodeId: map['src'] ?? '',
    destinationNodeId: map['dst'] ?? '',
    hopCount: map['hops'] ?? 1,
    ttl: map['ttl'] ?? 7,
    encryptedPayload: map['data'] ?? '',
    routedViaNodes: List<String>.from(map['route'] ?? []),
  );

  String serialize() => jsonEncode(toMap());
  factory MeshPacket.deserialize(String raw) => MeshPacket.fromMap(jsonDecode(raw));
}

/// Moteur de Réseau Maillé Décentralisé BENSALMAN (BLE + Wi-Fi Direct Mesh)
class MeshService extends ChangeNotifier {
  static final MeshService _instance = MeshService._internal();
  factory MeshService() => _instance;
  MeshService._internal();

  bool _isRadioActive = true;
  bool _isAdvertising = true;
  bool _isScanning = true;
  int _activePeersCount = 3;

  // Cache anti-bouclage des paquets déjà vus (Deduplication)
  final Set<String> _seenPacketIds = {};

  // File d'attente Store-and-Forward (Stockage hors-portée en attendant un relais)
  final List<MeshPacket> _storeAndForwardQueue = [];

  // Stream pour les messages entrants déchiffrés
  final _incomingMessageController = StreamController<MeshMessage>.broadcast();
  Stream<MeshMessage> get incomingMessages => _incomingMessageController.stream;

  bool get isRadioActive => _isRadioActive;
  bool get isAdvertising => _isAdvertising;
  bool get isScanning => _isScanning;
  int get activePeersCount => _activePeersCount;
  int get queueSize => _storeAndForwardQueue.length;

  /// Initialiser la radio locale BLE & Wi-Fi Direct
  Future<void> initialize(UserProfile localUser) async {
    _isRadioActive = true;
    _isAdvertising = true;
    _isScanning = true;
    notifyListeners();
  }

  /// Activer / Suspendre la radio pour économiser la batterie
  void toggleMeshRadio() {
    _isRadioActive = !_isRadioActive;
    notifyListeners();
  }

  /// Émission d'un message dans le maillage
  Future<bool> sendMeshMessage({
    required UserProfile sender,
    required Friend recipient,
    required String rawContent,
    required MessageType type,
    int? voiceDurationSeconds,
    String? imageCaption,
  }) async {
    final now = DateTime.now();
    final timeStr = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";
    final encrypted = CryptoService().encryptPayload(rawContent, recipient.publicKey);
    final packetId = "pkt_${now.millisecondsSinceEpoch}_${sender.id.substring(0, 4)}";

    final isDirect = recipient.status == FriendStatus.nearbyBle || recipient.status == FriendStatus.nearbyWifiDirect;

    final packet = MeshPacket(
      packetId: packetId,
      sourceNodeId: sender.id,
      destinationNodeId: recipient.id,
      hopCount: 1,
      ttl: 7,
      encryptedPayload: encrypted,
      routedViaNodes: [sender.id],
    );

    _seenPacketIds.add(packetId);

    // Si le nœud est hors de portée, router via les relais voisins (A -> B -> C)
    if (!isDirect) {
      // Propagation par inondation intelligente (Controlled Flooding)
      _relayPacket(packet, sender);
    } else {
      // Transmission directe en BLE / Wi-Fi Direct P2P
      _transmitOverRadio(packet);
    }

    return true;
  }

  /// Relayer un paquet reçu pour autrui (Store-and-Forward + Hop Decrement)
  void _relayPacket(MeshPacket packet, UserProfile localUser) {
    if (packet.ttl <= 1) return; // TTL expiré

    final relayedPacket = MeshPacket(
      packetId: packet.packetId,
      sourceNodeId: packet.sourceNodeId,
      destinationNodeId: packet.destinationNodeId,
      hopCount: packet.hopCount + 1,
      ttl: packet.ttl - 1,
      encryptedPayload: packet.encryptedPayload,
      routedViaNodes: [...packet.routedViaNodes, localUser.id],
    );

    // Envoi radio vers tous les voisins à portée
    _transmitOverRadio(relayedPacket);
  }

  void _transmitOverRadio(MeshPacket packet) {
    // Dans le moteur natif Android/Kotlin, ceci appelle:
    // BluetoothLeAdvertiser.startAdvertising(...) ou BluetoothGattServer.notifyCharacteristicChanged(...)
    // ou WifiP2pManager Socket transfer
  }

  @override
  void dispose() {
    _incomingMessageController.close();
    super.dispose();
  }
}
