import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'models/user_profile.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF0D0D0D),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const BensalmanMeshApp());
}

class BensalmanMeshApp extends StatelessWidget {
  const BensalmanMeshApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final localUser = UserProfile(
      id: 'salman_bah_me',
      name: 'Salman Bah',
      phone: '+212 6 00 00 00 00',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      publicKey: 'BEN-F14920E831BC679A',
      privateKey: 'SEC-991A8BC20F714201',
      deviceBleMac: 'F4:84:4C:E1:92:0A',
    );

    return MaterialApp(
      title: 'BENSALMAN 👑',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D0D0D),
        primaryColor: const Color(0xFFD4AF37),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFD4AF37),
          secondary: Color(0xFFAA820A),
          surface: Color(0xFF141414),
          background: Color(0xFF0D0D0D),
        ),
        fontFamily: 'Roboto',
      ),
      home: HomeScreen(user: localUser),
    );
  }
}
