import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ChatList } from './components/ChatList';
import { ChatRoom } from './components/ChatRoom';
import { MeshTopologyModal } from './components/MeshTopologyModal';
import { FriendRequestsModal } from './components/FriendRequestsModal';
import { DevisModal } from './components/DevisModal';
import { SettingsModal } from './components/SettingsModal';
import { AuthModal } from './components/AuthModal';
import { DownloadApkModal } from './components/DownloadApkModal';
import { DeviceSwitcher } from './components/DeviceSwitcher';
import {
  INITIAL_USER,
  INITIAL_FRIENDS,
  INITIAL_MESSAGES,
  INITIAL_INVITATIONS,
} from './data/mockData';
import { UserProfile, Friend, ChatMessage, FriendInvitation } from './types';
import { simulateEncrypt } from './utils/crypto';
import { MessageSquare, Radio, Share2, Shield, FileText, Download, FolderArchive } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<UserProfile>(INITIAL_USER);
  const [friends, setFriends] = useState<Friend[]>(INITIAL_FRIENDS);
  const [messages, setMessages] = useState<Record<string, ChatMessage[]>>(INITIAL_MESSAGES);
  const [invitations, setInvitations] = useState<FriendInvitation[]>(INITIAL_INVITATIONS);
  const [activeChatId, setActiveChatId] = useState<string>('friend_karim');
  const [isMeshActive, setIsMeshActive] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'chats' | 'friends' | 'mesh'>('chats');
  const [deviceRole, setDeviceRole] = useState<'salman' | 'karim' | 'amina'>('salman');

  // Modals
  const [isMeshModalOpen, setIsMeshModalOpen] = useState(false);
  const [isFriendsModalOpen, setIsFriendsModalOpen] = useState(false);
  const [isDevisModalOpen, setIsDevisModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isDownloadApkModalOpen, setIsDownloadApkModalOpen] = useState(false);

  // Active friend
  const activeFriend = friends.find((f) => f.id === activeChatId) || friends[0];

  // Send Message Handler
  const handleSendMessage = (
    content: string,
    type: 'text' | 'voice' | 'image',
    extra?: { voiceDurationSeconds?: number; imageCaption?: string }
  ) => {
    if (!activeFriend) return;

    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now
      .getMinutes()
      .toString()
      .padStart(2, '0')}`;

    const isRelayed = activeFriend.status === 'out_of_range_relay';
    const isBle = activeFriend.status === 'nearby_ble';

    const transportType = isRelayed
      ? 'MESH_RELAY'
      : isBle
      ? 'BLE_DIRECT'
      : 'INTERNET_FIREBASE';

    const hopsTrace = isRelayed
      ? [
          {
            nodeId: user.id,
            nodeName: user.name,
            method: 'BLE' as const,
            timestamp: timeStr,
          },
          {
            nodeId: 'friend_karim',
            nodeName: 'Karim Z. (Relais Mesh)',
            method: 'Wi-Fi Direct' as const,
            timestamp: timeStr,
          },
          {
            nodeId: activeFriend.id,
            nodeName: activeFriend.name,
            method: 'Wi-Fi Direct' as const,
            timestamp: timeStr,
          },
        ]
      : [
          {
            nodeId: user.id,
            nodeName: user.name,
            method: isBle ? ('BLE' as const) : ('Cloud' as const),
            timestamp: timeStr,
          },
          {
            nodeId: activeFriend.id,
            nodeName: activeFriend.name,
            method: isBle ? ('BLE' as const) : ('Cloud' as const),
            timestamp: timeStr,
          },
        ];

    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      chatId: activeFriend.id,
      senderId: user.id,
      senderName: user.name,
      recipientId: activeFriend.id,
      type,
      content,
      encryptedPayload: simulateEncrypt(content, activeFriend.publicKey),
      timestamp: timeStr,
      deliveryStatus: isRelayed ? 'relayed' : 'delivered',
      transport: transportType,
      hopsTrace,
      voiceDurationSeconds: extra?.voiceDurationSeconds,
      imageCaption: extra?.imageCaption,
    };

    setMessages((prev) => ({
      ...prev,
      [activeFriend.id]: [...(prev[activeFriend.id] || []), newMsg],
    }));

    // Simulate transition to read state after 1.5 seconds
    setTimeout(() => {
      setMessages((prev) => {
        const chatMsgs = prev[activeFriend.id] || [];
        return {
          ...prev,
          [activeFriend.id]: chatMsgs.map((m) =>
            m.id === newMsg.id ? { ...m, deliveryStatus: 'read' as const } : m
          ),
        };
      });
    }, 1600);
  };

  // Simulate an incoming reply
  const handleSimulateIncomingReply = () => {
    if (!activeFriend) return;

    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now
      .getMinutes()
      .toString()
      .padStart(2, '0')}`;

    const isRelayed = activeFriend.status === 'out_of_range_relay';

    const replies = [
      `Bien reçu sur mon terminal ! Zéro réseau cellulaire ni Wi-Fi, la liaison ${isRelayed ? 'Mesh par relais' : 'Bluetooth directe'} est ultra fluide 👑`,
      `Impressionnant le temps de latence en BLE ! Tout est chiffré de bout en bout.`,
      `Le relais radio BENSALMAN fonctionne parfaitement même sans carte SIM.`,
    ];

    const chosenText = replies[Math.floor(Math.random() * replies.length)];

    const replyMsg: ChatMessage = {
      id: `reply_${Date.now()}`,
      chatId: activeFriend.id,
      senderId: activeFriend.id,
      senderName: activeFriend.name,
      recipientId: user.id,
      type: 'text',
      content: chosenText,
      encryptedPayload: simulateEncrypt(chosenText, user.publicKey),
      timestamp: timeStr,
      deliveryStatus: 'delivered',
      transport: isRelayed ? 'MESH_RELAY' : 'BLE_DIRECT',
      hopsTrace: [
        {
          nodeId: activeFriend.id,
          nodeName: activeFriend.name,
          method: 'BLE',
          timestamp: timeStr,
        },
        {
          nodeId: user.id,
          nodeName: user.name,
          method: 'BLE',
          timestamp: timeStr,
        },
      ],
    };

    setMessages((prev) => ({
      ...prev,
      [activeFriend.id]: [...(prev[activeFriend.id] || []), replyMsg],
    }));
  };

  // Accept Friend Invitation (Mutual Consent Requirement)
  const handleAcceptInvitation = (invId: string) => {
    const inv = invitations.find((i) => i.id === invId);
    if (!inv) return;

    const newFriend: Friend = {
      id: `friend_${Date.now()}`,
      name: inv.fromName,
      phone: inv.fromPhone,
      avatar: inv.fromAvatar,
      status: 'nearby_ble',
      distanceMeters: 6,
      rssi: -68,
      hopsCount: 0,
      lastSeen: 'À l\'instant (BLE)',
      publicKey: '04:CC:88:11:44:77:22:99:AA:EE:33:55:77:99:BB:DD',
      unreadCount: 0,
    };

    setFriends((prev) => [newFriend, ...prev]);
    setInvitations((prev) => prev.filter((i) => i.id !== invId));
    setActiveChatId(newFriend.id);

    // Add initial system message explaining mutual consent established
    const welcomeMsg: ChatMessage = {
      id: `msg_welcome_${Date.now()}`,
      chatId: newFriend.id,
      senderId: newFriend.id,
      senderName: newFriend.name,
      recipientId: user.id,
      type: 'text',
      content: `Bonjour ${user.name} ! Consentement mutuel accepté. Nos clés E2E ont été échangées en toute sécurité via le maillage BLE.`,
      timestamp: 'À l\'instant',
      deliveryStatus: 'read',
      transport: 'BLE_DIRECT',
      hopsTrace: [],
    };

    setMessages((prev) => ({
      ...prev,
      [newFriend.id]: [welcomeMsg],
    }));
  };

  const handleRejectInvitation = (invId: string) => {
    setInvitations((prev) => prev.filter((i) => i.id !== invId));
  };

  const handleSendInvitation = (phone: string, name: string) => {
    // Send simulated outgoing invite
  };

  const handleResetData = () => {
    setUser(INITIAL_USER);
    setFriends(INITIAL_FRIENDS);
    setMessages(INITIAL_MESSAGES);
    setInvitations(INITIAL_INVITATIONS);
    setActiveChatId('friend_karim');
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#0D0D0D] text-[#E5E5E5] select-none font-sans">
      {/* Top Application Header */}
      <Header
        user={user}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isMeshActive={isMeshActive}
        setIsMeshActive={setIsMeshActive}
        onOpenMeshModal={() => setIsMeshModalOpen(true)}
        onOpenFriendsModal={() => setIsFriendsModalOpen(true)}
        onOpenDevisModal={() => setIsDevisModalOpen(true)}
        onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
        onOpenDownloadApkModal={() => setIsDownloadApkModalOpen(true)}
        pendingInvitationsCount={invitations.length}
      />

      {/* Device Simulation Switcher Bar */}
      <DeviceSwitcher
        currentRole={deviceRole}
        onSwitchRole={setDeviceRole}
        onSimulateIncomingReply={handleSimulateIncomingReply}
        activeFriend={activeFriend}
      />

      {/* Main WhatsApp-like Layout */}
      <div className="flex-1 flex overflow-hidden max-w-7xl w-full mx-auto relative">
        {/* Left Side: Chats & Contacts List */}
        <div
          className={`w-full md:w-80 lg:w-96 shrink-0 h-full flex flex-col ${
            activeChatId && window.innerWidth < 768 ? 'hidden md:flex' : 'flex'
          }`}
        >
          <ChatList
            friends={friends}
            activeChatId={activeChatId}
            onSelectChat={(id) => setActiveChatId(id)}
            lastMessages={messages}
            onOpenAddFriend={() => setIsFriendsModalOpen(true)}
          />
        </div>

        {/* Right Side: Active Chat Room */}
        <div
          className={`flex-1 h-full flex flex-col ${
            !activeChatId && window.innerWidth < 768 ? 'hidden md:flex' : 'flex'
          }`}
        >
          {activeFriend ? (
            <ChatRoom
              friend={activeFriend}
              user={user}
              messages={messages[activeFriend.id] || []}
              onSendMessage={handleSendMessage}
              onBack={() => setActiveChatId('')}
              onOpenMeshTopology={() => setIsMeshModalOpen(true)}
            />
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-8 text-center bg-[#0A0A0A] space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-black border border-[#D4AF37]/40 flex items-center justify-center shadow-lg">
                <span className="font-royal text-3xl font-bold text-[#D4AF37]">B</span>
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white font-royal">BENSALMAN 👑</h3>
                <p className="text-xs text-neutral-400 max-w-sm">
                  Sélectionnez un contact pour démarrer une conversation sans réseau via Bluetooth Low Energy et Wi-Fi Direct.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Floating Action CTAs in corner */}
      <div className="fixed bottom-4 right-4 z-20 flex items-center gap-2">
        <a
          id="floating-download-zip-cta"
          href="/bensalman-mesh-complet.zip"
          download="bensalman-mesh-complet.zip"
          className="flex items-center gap-2 px-3.5 py-2 rounded-full bg-[#181818] border border-[#D4AF37] text-[#FFD700] hover:bg-[#252008] font-bold text-xs shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
          title="Lien direct : Télécharger le ZIP du projet complet (Flutter & Android)"
        >
          <FolderArchive className="w-4 h-4 text-[#D4AF37]" />
          <span>ZIP Projet</span>
          <span className="bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#D4AF37] text-[10px] px-1.5 py-0.2 rounded-full font-mono">
            Direct
          </span>
        </a>

        <button
          id="floating-download-apk-cta"
          onClick={() => setIsDownloadApkModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-[#FFD700] via-[#D4AF37] to-[#AA820A] text-black font-black text-xs shadow-[0_0_25px_rgba(212,175,55,0.45)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
          title="Télécharger l'APK Android (bensalman-mesh-v1.0.0-release.apk)"
        >
          <Download className="w-4 h-4 stroke-[2.5]" />
          <span>Download APK</span>
          <span className="bg-black text-[#D4AF37] text-[10px] px-1.5 py-0.2 rounded-full font-mono font-black">
            v1.0
          </span>
        </button>

        <button
          id="floating-devis-cta"
          onClick={() => setIsDevisModalOpen(true)}
          className="hidden sm:flex items-center gap-2 px-3.5 py-2 rounded-full bg-[#181818] border border-[#D4AF37]/50 text-[#D4AF37] font-bold text-xs shadow-lg hover:scale-105 active:scale-95 transition-all cursor-pointer"
          title="Voir le devis détaillé & délai de développement"
        >
          <FileText className="w-4 h-4" />
          <span>Devis MVP</span>
          <span className="bg-black text-[#D4AF37] text-[10px] px-1.5 py-0.2 rounded-full font-mono font-black">
            11.2k€
          </span>
        </button>
      </div>

      {/* Modals */}
      <DownloadApkModal
        isOpen={isDownloadApkModalOpen}
        onClose={() => setIsDownloadApkModalOpen(false)}
      />

      <MeshTopologyModal
        isOpen={isMeshModalOpen}
        onClose={() => setIsMeshModalOpen(false)}
      />

      <FriendRequestsModal
        isOpen={isFriendsModalOpen}
        onClose={() => setIsFriendsModalOpen(false)}
        invitations={invitations}
        onAcceptInvitation={handleAcceptInvitation}
        onRejectInvitation={handleRejectInvitation}
        onSendInvitation={handleSendInvitation}
        friends={friends}
      />

      <DevisModal
        isOpen={isDevisModalOpen}
        onClose={() => setIsDevisModalOpen(false)}
      />

      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        user={user}
        onUpdateUser={(updated) => setUser((u) => ({ ...u, ...updated }))}
        onResetData={handleResetData}
        onOpenAuth={() => {
          setIsSettingsModalOpen(false);
          setIsAuthModalOpen(true);
        }}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        user={user}
        onUpdateUser={(updated) => setUser((u) => ({ ...u, ...updated }))}
      />
    </div>
  );
}
