import { UserProfile, Friend, ChatMessage, FriendInvitation, MeshTopologyNode } from '../types';

export const INITIAL_USER: UserProfile = {
  id: 'user_salman',
  name: 'Salman Bah',
  phone: '+33 6 12 34 56 78',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  statusMessage: 'BENSALMAN 👑 Toujours joignable en Mesh BLE',
  publicKey: '04:8F:2A:44:B1:99:EE:12:77:30:45:62:FF:11:00:88',
  isRegistered: true,
  batteryLevel: 88,
  bleEnabled: true,
  wifiDirectEnabled: true,
  isRelayActive: true,
};

export const INITIAL_FRIENDS: Friend[] = [
  {
    id: 'friend_karim',
    name: 'Karim Z.',
    phone: '+33 6 98 76 54 32',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    status: 'nearby_ble',
    distanceMeters: 4,
    rssi: -62,
    hopsCount: 0,
    lastSeen: 'À l\'instant (BLE)',
    publicKey: '04:11:34:67:89:AB:CD:EF:01:23:45:67:89:AB:CD:EF',
    unreadCount: 1,
    pinned: true,
  },
  {
    id: 'friend_amina',
    name: 'Amina K.',
    phone: '+33 7 45 67 89 01',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    status: 'out_of_range_relay',
    distanceMeters: 42,
    rssi: -94,
    relayNodeName: 'Karim Z. (Relais BLE)',
    hopsCount: 1,
    lastSeen: 'Relayé via Karim (BLE)',
    publicKey: '04:99:88:77:66:55:44:33:22:11:00:FF:EE:DD:CC:BB',
    unreadCount: 0,
    pinned: true,
  },
  {
    id: 'friend_omar',
    name: 'Omar D.',
    phone: '+33 6 33 22 11 00',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    status: 'online',
    hopsCount: 0,
    lastSeen: 'En ligne (Cloud Firestore)',
    publicKey: '04:AA:BB:CC:DD:EE:FF:00:11:22:33:44:55:66:77:88',
    unreadCount: 0,
  },
  {
    id: 'friend_youssef',
    name: 'Dr. Youssef B.',
    phone: '+33 6 55 44 33 22',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    status: 'nearby_ble',
    distanceMeters: 12,
    rssi: -78,
    hopsCount: 0,
    lastSeen: 'Il y a 3 min (BLE)',
    publicKey: '04:12:45:78:01:34:67:90:23:56:89:12:45:78:01:34',
    unreadCount: 0,
  },
  {
    id: 'friend_sarah',
    name: 'Sarah M.',
    phone: '+33 7 88 99 00 11',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    status: 'out_of_range_relay',
    distanceMeters: 85,
    rssi: -105,
    relayNodeName: 'Dr. Youssef B. (Relais)',
    hopsCount: 2,
    lastSeen: 'Relayé via 2 sauts (Mesh)',
    publicKey: '04:55:66:77:88:99:AA:BB:CC:DD:EE:FF:00:11:22:33',
    unreadCount: 0,
  },
];

export const INITIAL_MESSAGES: Record<string, ChatMessage[]> = {
  friend_karim: [
    {
      id: 'msg_k1',
      chatId: 'friend_karim',
      senderId: 'friend_karim',
      senderName: 'Karim Z.',
      recipientId: 'user_salman',
      type: 'text',
      content: 'Salam Salman ! Mon Bluetooth est activé. Tu me reçois en direct sans réseau ?',
      encryptedPayload: 'E2E::v1[k92a]::==310xZbBwXZ==',
      timestamp: '14:22',
      deliveryStatus: 'read',
      transport: 'BLE_DIRECT',
      hopsTrace: [
        { nodeId: 'friend_karim', nodeName: 'Karim Z.', method: 'BLE', timestamp: '14:22:01' },
        { nodeId: 'user_salman', nodeName: 'Salman Bah', method: 'BLE', timestamp: '14:22:02' }
      ]
    },
    {
      id: 'msg_k2',
      chatId: 'friend_karim',
      senderId: 'user_salman',
      senderName: 'Salman Bah',
      recipientId: 'friend_karim',
      type: 'text',
      content: 'Parfaitement reçu ! RSSI à -62 dBm, distance estimée 4 mètres. Zéro internet nécessaire 👑',
      encryptedPayload: 'E2E::v1[w91b]::==540aBwZXo9==',
      timestamp: '14:23',
      deliveryStatus: 'read',
      transport: 'BLE_DIRECT',
      hopsTrace: [
        { nodeId: 'user_salman', nodeName: 'Salman Bah', method: 'BLE', timestamp: '14:23:01' },
        { nodeId: 'friend_karim', nodeName: 'Karim Z.', method: 'BLE', timestamp: '14:23:02' }
      ]
    },
    {
      id: 'msg_k3',
      chatId: 'friend_karim',
      senderId: 'friend_karim',
      senderName: 'Karim Z.',
      recipientId: 'user_salman',
      type: 'voice',
      content: 'simulation_audio_blob',
      voiceDurationSeconds: 8,
      timestamp: '14:25',
      deliveryStatus: 'delivered',
      transport: 'BLE_DIRECT',
      hopsTrace: [
        { nodeId: 'friend_karim', nodeName: 'Karim Z.', method: 'BLE', timestamp: '14:25:01' },
        { nodeId: 'user_salman', nodeName: 'Salman Bah', method: 'BLE', timestamp: '14:25:02' }
      ]
    }
  ],
  friend_amina: [
    {
      id: 'msg_a1',
      chatId: 'friend_amina',
      senderId: 'friend_amina',
      senderName: 'Amina K.',
      recipientId: 'user_salman',
      type: 'text',
      content: 'Bonjour Salman, je suis à 42m dans l\'autre bâtiment sans réseau 4G ni Wi-Fi !',
      encryptedPayload: 'E2E::v1[am88]::==00abCD1234==',
      timestamp: '14:10',
      deliveryStatus: 'read',
      transport: 'MESH_RELAY',
      hopsTrace: [
        { nodeId: 'friend_amina', nodeName: 'Amina K.', method: 'BLE', timestamp: '14:10:00' },
        { nodeId: 'friend_karim', nodeName: 'Karim Z. (Relais Mesh)', method: 'BLE', timestamp: '14:10:01' },
        { nodeId: 'user_salman', nodeName: 'Salman Bah', method: 'BLE', timestamp: '14:10:03' }
      ]
    },
    {
      id: 'msg_a2',
      chatId: 'friend_amina',
      senderId: 'user_salman',
      senderName: 'Salman Bah',
      recipientId: 'friend_amina',
      type: 'text',
      content: 'Incroyable ! Ton paquet est passé par le téléphone de Karim qui a servi de relais transparent. Et Karim ne peut pas lire le message grâce au chiffrement E2E ! 🛡️',
      encryptedPayload: 'E2E::v1[sl01]::==99zxQW5678==',
      timestamp: '14:12',
      deliveryStatus: 'read',
      transport: 'MESH_RELAY',
      hopsTrace: [
        { nodeId: 'user_salman', nodeName: 'Salman Bah', method: 'BLE', timestamp: '14:12:00' },
        { nodeId: 'friend_karim', nodeName: 'Karim Z. (Relais)', method: 'BLE', timestamp: '14:12:01' },
        { nodeId: 'friend_amina', nodeName: 'Amina K.', method: 'Wi-Fi Direct', timestamp: '14:12:03' }
      ]
    }
  ],
  friend_omar: [
    {
      id: 'msg_o1',
      chatId: 'friend_omar',
      senderId: 'friend_omar',
      senderName: 'Omar D.',
      recipientId: 'user_salman',
      type: 'text',
      content: 'Hello Salman, je suis connecté en 5G, synchronisation Cloud Firebase active.',
      timestamp: 'Hier',
      deliveryStatus: 'read',
      transport: 'INTERNET_FIREBASE',
      hopsTrace: [
        { nodeId: 'friend_omar', nodeName: 'Omar D.', method: 'Cloud', timestamp: 'Hier 18:00' },
        { nodeId: 'user_salman', nodeName: 'Salman Bah', method: 'Cloud', timestamp: 'Hier 18:00' }
      ]
    }
  ]
};

export const INITIAL_INVITATIONS: FriendInvitation[] = [
  {
    id: 'inv_1',
    fromPhone: '+33 6 44 88 12 90',
    fromName: 'Tariq Al-Mansoor',
    fromAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    toPhone: '+33 6 12 34 56 78',
    createdAt: 'Il y a 10 minutes',
    status: 'pending'
  }
];

export const MESH_TOPOLOGY_NODES: MeshTopologyNode[] = [
  {
    id: 'user_salman',
    name: 'Salman Bah (Vous)',
    phone: '+33 6 12 34 56 78',
    role: 'sender',
    x: 180,
    y: 220,
    status: 'nearby_ble',
    distanceToMe: 0,
    battery: 88,
    connections: ['friend_karim', 'friend_youssef']
  },
  {
    id: 'friend_karim',
    name: 'Karim Z. (Relais Actif)',
    phone: '+33 6 98 76 54 32',
    role: 'relay',
    x: 340,
    y: 150,
    status: 'nearby_ble',
    distanceToMe: 4,
    battery: 92,
    connections: ['user_salman', 'friend_amina']
  },
  {
    id: 'friend_amina',
    name: 'Amina K. (Destinataire)',
    phone: '+33 7 45 67 89 01',
    role: 'recipient',
    x: 520,
    y: 190,
    status: 'out_of_range_relay',
    distanceToMe: 42,
    battery: 76,
    connections: ['friend_karim', 'friend_sarah']
  },
  {
    id: 'friend_youssef',
    name: 'Dr. Youssef B. (Nœud BLE)',
    phone: '+33 6 55 44 33 22',
    role: 'peer',
    x: 230,
    y: 350,
    status: 'nearby_ble',
    distanceToMe: 12,
    battery: 65,
    connections: ['user_salman', 'friend_sarah']
  },
  {
    id: 'friend_sarah',
    name: 'Sarah M. (Nœud lointain)',
    phone: '+33 7 88 99 00 11',
    role: 'peer',
    x: 460,
    y: 340,
    status: 'out_of_range_relay',
    distanceToMe: 85,
    battery: 81,
    connections: ['friend_youssef', 'friend_amina']
  }
];
