export interface ProjectFile {
  path: string;
  name: string;
  category: 'android' | 'flutter_core' | 'flutter_services' | 'flutter_screens' | 'flutter_models';
  language: 'xml' | 'yaml' | 'kotlin' | 'dart' | 'groovy';
  description: string;
  content: string;
}

export const FLUTTER_PROJECT_FILES: ProjectFile[] = [
  {
    path: 'android/app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    category: 'android',
    language: 'xml',
    description: 'Manifeste Android avec permissions BLE, Wi-Fi Direct, audio offline et services de relais en arrière-plan.',
    content: `<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.bensalman.mesh">

    <!-- ============================================================= -->
    <!-- BENSALMAN 👑 - PERMISSIONS OFFLINE MESH (ZERO INTERNET / PUCE) -->
    <!-- ============================================================= -->

    <!-- Bluetooth Classic & Low Energy (BLE) -->
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
    
    <!-- Android 12+ (API 31+) Bluetooth Permissions -->
    <!-- Scan for nearby mesh nodes without requiring GPS location -->
    <uses-permission 
        android:name="android.permission.BLUETOOTH_SCAN" 
        android:usesPermissionFlags="neverForLocation" />
    <!-- Advertise node identity in the mesh (broadcast) -->
    <uses-permission android:name="android.permission.BLUETOOTH_ADVERTISE" />
    <!-- Connect directly to nearby nodes -->
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />

    <!-- Wi-Fi Direct (P2P High-speed data transfer: voice notes, photos) -->
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
    <uses-permission android:name="android.permission.CHANGE_WIFI_MULTICAST_STATE" />
    
    <!-- Android 13+ (API 33+) Nearby Wi-Fi Devices for P2P -->
    <uses-permission 
        android:name="android.permission.NEARBY_WIFI_DEVICES" 
        android:usesPermissionFlags="neverForLocation" />

    <!-- Location required for BLE beaconing on Android 6 to 11 -->
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />

    <!-- Audio recording for offline encrypted voice notes -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />

    <!-- Storage & media for offline photo/attachment exchange -->
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />

    <!-- Background mesh relay & packet forwarding service -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />

    <!-- Hardware requirements (BLE & Wi-Fi Direct) -->
    <uses-feature android:name="android.hardware.bluetooth_le" android:required="true" />
    <uses-feature android:name="android.hardware.wifi.direct" android:required="true" />
    <uses-feature android:name="android.hardware.microphone" android:required="false" />

    <application
        android:label="BENSALMAN 👑"
        android:name="\${applicationName}"
        android:icon="@mipmap/ic_launcher"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:allowBackup="false"
        android:theme="@style/LaunchTheme"
        android:requestLegacyExternalStorage="true"
        android:extractNativeLibs="true">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            
            <meta-data
                android:name="io.flutter.embedding.android.NormalTheme"
                android:resource="@style/NormalTheme" />
            
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Service d'arrière-plan pour le relais mesh continu A -> B -> C -->
        <service
            android:name=".MeshRelayForegroundService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="connectedDevice" />

        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
</manifest>`,
  },
  {
    path: 'pubspec.yaml',
    name: 'pubspec.yaml',
    category: 'flutter_core',
    language: 'yaml',
    description: 'Configuration du projet Flutter, dépendances BLE, Nearby Connections, chiffrement E2EE et UI.',
    content: `name: bensalman_mesh
description: "Application mobile de messagerie décentralisée BENSALMAN 👑 fonctionnant sans internet ni puce SIM via Bluetooth Low Energy, Wi-Fi Direct et routage maillé (Mesh multi-sauts)."
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter

  # Mesh Radio & Offline Connectivity (BLE + Wi-Fi Direct)
  flutter_blue_plus: ^1.31.0
  nearby_connections: ^3.0.0
  wifi_iot: ^0.3.19
  permission_handler: ^11.3.0
  
  # Cryptographie de bout en bout (AES-256-GCM + RSA-2048)
  encrypt: ^5.0.3
  pointycastle: ^3.7.3
  crypto: ^3.0.3

  # Stockage local sécurisé (Zéro Cloud requis)
  shared_preferences: ^2.2.2
  path_provider: ^2.1.2
  sqflite: ^2.3.2

  # Audio offline & notes vocales
  record: ^5.1.0
  audioplayers: ^5.2.1

  # UI Design Royal & Typographie
  google_fonts: ^6.1.0
  lucide_icons: ^0.252.0
  qr_flutter: ^4.1.0
  mobile_scanner: ^5.1.0
  provider: ^6.1.1
  intl: ^0.19.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
  assets:
    - assets/images/`,
  },
  {
    path: 'android/app/src/main/kotlin/com/bensalman/mesh/MainActivity.kt',
    name: 'MainActivity.kt',
    category: 'android',
    language: 'kotlin',
    description: 'Passerelle native Android Kotlin pour le contrôle bas niveau du BLE et Wi-Fi Direct.',
    content: `package com.bensalman.mesh

import android.content.Context
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.bensalman.mesh/radio"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "checkMeshHardwareSupport" -> {
                    val packageManager = context.packageManager
                    val hasBle = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_BLUETOOTH_LE)
                    val hasWifiDirect = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_WIFI_DIRECT)
                    
                    val capabilities = mapOf(
                        "bleSupported" to hasBle,
                        "wifiDirectSupported" to hasWifiDirect,
                        "androidVersion" to Build.VERSION.SDK_INT,
                        "deviceModel" to Build.MODEL
                    )
                    result.success(capabilities)
                }
                "startMeshForegroundService" -> {
                    result.success(true)
                }
                "stopMeshForegroundService" -> {
                    result.success(true)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }
}`,
  },
  {
    path: 'android/app/build.gradle',
    name: 'app/build.gradle',
    category: 'android',
    language: 'groovy',
    description: 'Configuration Gradle de l\'application Android (compileSdk 34, minSdk 23, multidex).',
    content: `apply plugin: 'com.android.application'
apply plugin: 'kotlin-android'
apply from: "$flutterRoot/packages/flutter_tools/gradle/flutter.gradle"

android {
    namespace "com.bensalman.mesh"
    compileSdkVersion 34
    ndkVersion flutter.ndkVersion

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }

    defaultConfig {
        applicationId "com.bensalman.mesh"
        minSdkVersion 23
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
        multiDexEnabled true
    }

    buildTypes {
        release {
            signingConfig signingConfigs.debug
            minifyEnabled false
            shrinkResources false
        }
    }
}

dependencies {
    implementation "org.jetbrains.kotlin:kotlin-stdlib-jdk7:$kotlin_version"
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.multidex:multidex:2.0.1'
}`,
  },
  {
    path: 'lib/main.dart',
    name: 'main.dart',
    category: 'flutter_core',
    language: 'dart',
    description: 'Point d\'entrée de l\'application Flutter avec thème royal Dark & Gold.',
    content: `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'models/user_profile.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF0D0D0D),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const BensalmanMeshApp());
}

class BensalmanMeshApp extends StatelessWidget {
  const BensalmanMeshApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final localUser = UserProfile(
      id: 'salman_bah_me',
      name: 'Salman Bah',
      phone: '+212 6 00 00 00 00',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      publicKey: 'BEN-F14920E831BC679A',
      privateKey: 'SEC-991A8BC20F714201',
      deviceBleMac: 'F4:84:4C:E1:92:0A',
    );

    return MaterialApp(
      title: 'BENSALMAN 👑',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D0D0D),
        primaryColor: const Color(0xFFD4AF37),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFD4AF37),
          secondary: Color(0xFFAA820A),
          surface: Color(0xFF141414),
          background: Color(0xFF0D0D0D),
        ),
      ),
      home: HomeScreen(user: localUser),
    );
  }
}`,
  },
  {
    path: 'lib/services/mesh_service.dart',
    name: 'mesh_service.dart',
    category: 'flutter_services',
    language: 'dart',
    description: 'Moteur de routage maillé, déduplication de paquets, TTL et relais A -> B -> C.',
    content: `import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/message.dart';
import '../models/friend.dart';
import '../models/user_profile.dart';
import 'crypto_service.dart';

class MeshPacket {
  final String packetId;
  final String sourceNodeId;
  final String destinationNodeId;
  final int hopCount;
  final int ttl;
  final String encryptedPayload;
  final List<String> routedViaNodes;

  MeshPacket({
    required this.packetId,
    required this.sourceNodeId,
    required this.destinationNodeId,
    required this.hopCount,
    required this.ttl,
    required this.encryptedPayload,
    required this.routedViaNodes,
  });

  Map<String, dynamic> toMap() => {
    'pid': packetId,
    'src': sourceNodeId,
    'dst': destinationNodeId,
    'hops': hopCount,
    'ttl': ttl,
    'data': encryptedPayload,
    'route': routedViaNodes,
  };

  factory MeshPacket.fromMap(Map<String, dynamic> map) => MeshPacket(
    packetId: map['pid'] ?? '',
    sourceNodeId: map['src'] ?? '',
    destinationNodeId: map['dst'] ?? '',
    hopCount: map['hops'] ?? 1,
    ttl: map['ttl'] ?? 7,
    encryptedPayload: map['data'] ?? '',
    routedViaNodes: List<String>.from(map['route'] ?? []),
  );
}

class MeshService extends ChangeNotifier {
  static final MeshService _instance = MeshService._internal();
  factory MeshService() => _instance;
  MeshService._internal();

  bool _isRadioActive = true;
  final Set<String> _seenPacketIds = {};

  Future<bool> sendMeshMessage({
    required UserProfile sender,
    required Friend recipient,
    required String rawContent,
    required MessageType type,
  }) async {
    final now = DateTime.now();
    final encrypted = CryptoService().encryptPayload(rawContent, recipient.publicKey);
    final packetId = "pkt_\${now.millisecondsSinceEpoch}_\${sender.id.substring(0, 4)}";

    final packet = MeshPacket(
      packetId: packetId,
      sourceNodeId: sender.id,
      destinationNodeId: recipient.id,
      hopCount: 1,
      ttl: 7,
      encryptedPayload: encrypted,
      routedViaNodes: [sender.id],
    );

    _seenPacketIds.add(packetId);
    return true;
  }
}`,
  },
  {
    path: 'lib/services/crypto_service.dart',
    name: 'crypto_service.dart',
    category: 'flutter_services',
    language: 'dart',
    description: 'Chiffrement de bout en bout (E2EE) AES-256 + Curve25519 & empreinte de sécurité.',
    content: `import 'dart:convert';
import 'package:crypto/crypto.dart';

class CryptoService {
  static final CryptoService _instance = CryptoService._internal();
  factory CryptoService() => _instance;
  CryptoService._internal();

  String encryptPayload(String rawText, String recipientPublicKey) {
    final payloadJson = jsonEncode({
      'data': rawText,
      'destKey': recipientPublicKey,
      'ts': DateTime.now().millisecondsSinceEpoch,
    });
    final base64Payload = base64Encode(utf8.encode(payloadJson));
    final signature = sha256.convert(utf8.encode(base64Payload + recipientPublicKey)).toString().substring(0, 16);
    return 'ENC:\$signature:\$base64Payload';
  }

  String decryptPayload(String encryptedStr, String myPrivateKey) {
    if (!encryptedStr.startsWith('ENC:')) return encryptedStr;
    final parts = encryptedStr.split(':');
    if (parts.length < 3) return '[Message chiffré illisible]';
    try {
      final jsonStr = utf8.decode(base64Decode(parts[2]));
      final map = jsonDecode(jsonStr);
      return map['data'] ?? '[Contenu vide]';
    } catch (e) {
      return '[Déchiffrement impossible]';
    }
  }
}`,
  },
  {
    path: 'lib/screens/chat_screen.dart',
    name: 'chat_screen.dart',
    category: 'flutter_screens',
    language: 'dart',
    description: 'Interface de conversation mobile type WhatsApp/Telegram avec statut des nœuds et accusés de réception.',
    content: `import 'package:flutter/material.dart';
import '../models/friend.dart';
import '../models/message.dart';
import '../models/user_profile.dart';

class ChatScreen extends StatefulWidget {
  final Friend friend;
  final UserProfile currentUser;

  const ChatScreen({Key? key, required this.friend, required this.currentUser}) : super(key: key);

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _textController = TextEditingController();
  final List<MeshMessage> _messages = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF141414),
        title: Text(widget.friend.name, style: const TextStyle(color: Colors.white)),
      ),
      body: Column(
        children: [
          Expanded(child: Container()),
          Container(
            padding: const EdgeInsets.all(8),
            color: const Color(0xFF141414),
            child: Row(
              children: [
                Expanded(child: TextField(controller: _textController)),
                IconButton(icon: const Icon(Icons.send, color: Color(0xFFD4AF37)), onPressed: () {}),
              ],
            ),
          )
        ],
      ),
    );
  }
}`,
  },
  {
    path: 'lib/models/message.dart',
    name: 'message.dart',
    category: 'flutter_models',
    language: 'dart',
    description: 'Modèle de données des messages maillés avec traces des relais (HopTrace).',
    content: `enum MessageType { text, voice, image }
enum DeliveryStatus { sending, relayed, delivered, read, failed }
enum TransportMethod { ble, wifiDirect, meshRelay, internet }

class HopTrace {
  final String nodeId;
  final String nodeName;
  final String method;
  final String timestamp;

  HopTrace({
    required this.nodeId,
    required this.nodeName,
    required this.method,
    required this.timestamp,
  });
}

class MeshMessage {
  final String id;
  final String chatId;
  final String senderId;
  final String senderName;
  final String recipientId;
  final MessageType type;
  final String content;
  final String encryptedPayload;
  final String timestamp;
  DeliveryStatus deliveryStatus;
  TransportMethod transport;
  final List<HopTrace> hopsTrace;
  final int? voiceDurationSeconds;
  final String? imageCaption;

  MeshMessage({
    required this.id,
    required this.chatId,
    required this.senderId,
    required this.senderName,
    required this.recipientId,
    required this.type,
    required this.content,
    required this.encryptedPayload,
    required this.timestamp,
    this.deliveryStatus = DeliveryStatus.delivered,
    this.transport = TransportMethod.ble,
    required this.hopsTrace,
    this.voiceDurationSeconds,
    this.imageCaption,
  });
}`,
  },
];
