/**
 * E2E Cryptography utilities for BENSALMAN (AES-256-GCM + X25519 simulation)
 */

export function generateKeyPair() {
  const chars = '0123456789ABCDEF';
  let pub = '04:';
  for (let i = 0; i < 32; i++) {
    pub += chars[Math.floor(Math.random() * chars.length)];
    if (i % 2 === 1 && i < 31) pub += ':';
  }
  return {
    publicKey: pub,
    privateKey: 'priv_' + Math.random().toString(36).substring(2, 15)
  };
}

export function simulateEncrypt(plainText: string, recipientPublicKey: string): string {
  // Generate realistic-looking AES-GCM ciphertext block
  const b64 = btoa(unescape(encodeURIComponent(plainText)));
  const fakeNonce = Math.random().toString(36).substring(2, 10);
  return `E2E::v1[${fakeNonce}]::${b64.split('').reverse().join('')}==`;
}

export function simulateDecrypt(cipherText: string): string {
  try {
    if (cipherText.startsWith('E2E::v1')) {
      const parts = cipherText.split('::');
      const b64Reversed = parts[2].replace(/==$/, '');
      const b64 = b64Reversed.split('').reverse().join('') + '==';
      return decodeURIComponent(escape(atob(b64)));
    }
    return cipherText;
  } catch (e) {
    return cipherText;
  }
}

export function getSecurityFingerprint(keyA: string, keyB: string): string {
  let hash = 0;
  const combined = keyA + keyB;
  for (let i = 0; i < combined.length; i++) {
    hash = (hash << 5) - hash + combined.charCodeAt(i);
    hash |= 0;
  }
  const positive = Math.abs(hash).toString().padStart(12, '0');
  return `${positive.slice(0, 4)} ${positive.slice(4, 8)} ${positive.slice(8, 12)}`;
}
