export type ConnectivityStatus = 'online' | 'nearby_ble' | 'out_of_range_relay' | 'disconnected';

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  avatar: string;
  statusMessage: string;
  publicKey: string;
  isRegistered: boolean;
  batteryLevel: number;
  bleEnabled: boolean;
  wifiDirectEnabled: boolean;
  isRelayActive: boolean;
}

export interface Friend {
  id: string;
  name: string;
  phone: string;
  avatar: string;
  status: ConnectivityStatus;
  distanceMeters?: number; // e.g. 3m, 14m
  rssi?: number; // e.g. -54 dBm
  relayNodeName?: string; // e.g. "Karim (Relais BLE)"
  hopsCount: number; // 0 = direct online/ble, 1 = 1 hop via relay, 2 = 2 hops
  lastSeen: string;
  publicKey: string;
  unreadCount: number;
  pinned?: boolean;
}

export type MessageType = 'text' | 'voice' | 'image';

export type DeliveryStatus = 'sending' | 'relayed' | 'delivered' | 'read';

export interface MeshHopTrace {
  nodeId: string;
  nodeName: string;
  method: 'BLE' | 'Wi-Fi Direct' | 'Cloud';
  timestamp: string;
}

export interface ChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  recipientId: string;
  type: MessageType;
  content: string; // text content, voice duration/blob url, or base64/url for image
  encryptedPayload?: string; // simulation of AES-256 ciphertext
  timestamp: string;
  deliveryStatus: DeliveryStatus;
  transport: 'BLE_DIRECT' | 'MESH_RELAY' | 'INTERNET_FIREBASE';
  hopsTrace: MeshHopTrace[];
  voiceDurationSeconds?: number;
  imageCaption?: string;
}

export interface FriendInvitation {
  id: string;
  fromPhone: string;
  fromName: string;
  fromAvatar: string;
  toPhone: string;
  createdAt: string;
  status: 'pending' | 'accepted' | 'rejected';
}

export interface MeshTopologyNode {
  id: string;
  name: string;
  phone: string;
  role: 'sender' | 'relay' | 'recipient' | 'peer';
  x: number;
  y: number;
  status: ConnectivityStatus;
  distanceToMe: number;
  battery: number;
  connections: string[]; // node IDs connected via BLE/Wifi Direct
}
