import React, { useState } from 'react';
import { UserPlus, Check, X, Shield, Phone, ArrowRight, UserCheck, AlertCircle } from 'lucide-react';
import { FriendInvitation, Friend } from '../types';

interface FriendRequestsModalProps {
  isOpen: boolean;
  onClose: () => void;
  invitations: FriendInvitation[];
  onAcceptInvitation: (invitationId: string) => void;
  onRejectInvitation: (invitationId: string) => void;
  onSendInvitation: (phone: string, name: string) => void;
  friends: Friend[];
}

export const FriendRequestsModal: React.FC<FriendRequestsModalProps> = ({
  isOpen,
  onClose,
  invitations,
  onAcceptInvitation,
  onRejectInvitation,
  onSendInvitation,
  friends,
}) => {
  const [newPhone, setNewPhone] = useState('');
  const [newName, setNewName] = useState('');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPhone.trim()) return;

    onSendInvitation(newPhone.trim(), newName.trim() || 'Contact ' + newPhone.slice(-4));
    setSuccessMessage(`Invitation envoyée à ${newPhone}. En attente du consentement mutuel.`);
    setNewPhone('');
    setNewName('');

    setTimeout(() => {
      setSuccessMessage(null);
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#121212] border border-[#D4AF37]/40 rounded-3xl max-w-xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-[0_0_40px_rgba(212,175,55,0.15)]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#242424] flex items-center justify-between bg-[#161616]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#1E1A0A] border border-[#D4AF37]/50 flex items-center justify-center text-[#D4AF37]">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold font-royal text-[#E5E5E5] flex items-center gap-2">
                <span>Ajout d'Amis & Consentement Mutuel</span>
                <span className="text-[#D4AF37]">👑</span>
              </h2>
              <p className="text-xs text-neutral-400">
                La messagerie offline exige une autorisation réciproque bilatérale
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 flex items-center justify-center text-sm font-bold"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {/* Form to send new invitation */}
          <div className="bg-[#171717] rounded-2xl border border-neutral-800 p-4 space-y-3">
            <h3 className="text-xs uppercase font-bold tracking-wider text-[#D4AF37] flex items-center gap-2">
              <Phone className="w-3.5 h-3.5" />
              <span>Inviter un contact par numéro</span>
            </h3>

            <form onSubmit={handleSend} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-neutral-400 block mb-1">Nom / Pseudonyme</label>
                  <input
                    type="text"
                    placeholder="Ex: Tariq Al-Mansoor"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full bg-[#0E0E0E] border border-neutral-700 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-neutral-400 block mb-1">Numéro de téléphone</label>
                  <input
                    type="tel"
                    required
                    placeholder="+33 6 44 88 12 90"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    className="w-full bg-[#0E0E0E] border border-neutral-700 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-neutral-500">
                  Notification envoyée avec clé publique d'invitation
                </span>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B38C22] text-black font-bold text-xs hover:brightness-110 shadow"
                >
                  Envoyer l'invitation
                </button>
              </div>
            </form>

            {successMessage && (
              <div className="p-2.5 rounded-xl bg-[#1E1905] border border-[#D4AF37]/50 text-[#D4AF37] text-xs flex items-center gap-2">
                <Check className="w-4 h-4 shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}
          </div>

          {/* Pending Invitations requiring MUTUAL CONSENT */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs uppercase font-bold tracking-wider text-neutral-300 flex items-center gap-2">
                <Shield className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Invitations Reçues (Action Requise)</span>
              </h3>
              <span className="text-xs text-[#D4AF37] font-semibold bg-[#D4AF37]/10 px-2 py-0.5 rounded-full">
                {invitations.length} en attente
              </span>
            </div>

            {invitations.length === 0 ? (
              <div className="p-4 rounded-xl bg-[#151515] border border-neutral-800 text-center text-xs text-neutral-500">
                Aucune demande en attente. Votre réseau est synchronisé.
              </div>
            ) : (
              <div className="space-y-2">
                {invitations.map((inv) => (
                  <div
                    key={inv.id}
                    className="p-3.5 rounded-2xl bg-[#181818] border border-[#D4AF37]/30 flex items-center justify-between gap-3 shadow-md"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={inv.fromAvatar}
                        alt={inv.fromName}
                        referrerPolicy="no-referrer"
                        className="w-11 h-11 rounded-full object-cover border border-[#D4AF37]"
                      />
                      <div className="min-w-0">
                        <div className="text-sm font-bold text-white truncate flex items-center gap-1.5">
                          <span>{inv.fromName}</span>
                          <span className="text-[10px] text-[#D4AF37] bg-[#D4AF37]/20 px-1.5 rounded">
                            Consentement demandé
                          </span>
                        </div>
                        <div className="text-xs text-neutral-400 font-mono">{inv.fromPhone}</div>
                        <div className="text-[10px] text-neutral-500 mt-0.5">{inv.createdAt}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => onRejectInvitation(inv.id)}
                        className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-red-400 transition-colors"
                        title="Refuser"
                      >
                        <X className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onAcceptInvitation(inv.id)}
                        className="px-3 py-2 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B38C22] text-black font-bold text-xs flex items-center gap-1.5 shadow hover:brightness-110"
                        title="Accepter et autoriser l'échange Mesh"
                      >
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>Accepter</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Current Connected Friends List */}
          <div className="space-y-3">
            <h3 className="text-xs uppercase font-bold tracking-wider text-neutral-400 flex items-center gap-2">
              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Amis Autorisés en Mode Offline ({friends.length})</span>
            </h3>

            <div className="divide-y divide-neutral-800/80 bg-[#161616] rounded-2xl border border-neutral-800 overflow-hidden">
              {friends.map((f) => (
                <div key={f.id} className="p-3 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <img
                      src={f.avatar}
                      alt={f.name}
                      referrerPolicy="no-referrer"
                      className="w-9 h-9 rounded-full object-cover"
                    />
                    <div>
                      <div className="font-semibold text-neutral-200">{f.name}</div>
                      <div className="text-neutral-500 font-mono text-[11px]">{f.phone}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-emerald-400 bg-emerald-950/40 border border-emerald-500/20 px-2 py-0.5 rounded-full font-mono">
                      Clé E2E Validée
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#242424] bg-[#161616] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#D4AF37] text-black font-bold text-xs hover:brightness-110"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
