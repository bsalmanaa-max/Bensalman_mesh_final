import React, { useState } from 'react';
import { Search, Radio, Wifi, Share2, Circle, ArrowRight, Zap, WifiOff } from 'lucide-react';
import { Friend, ChatMessage } from '../types';

interface ChatListProps {
  friends: Friend[];
  activeChatId: string | null;
  onSelectChat: (friendId: string) => void;
  lastMessages: Record<string, ChatMessage[]>;
  onOpenAddFriend: () => void;
}

export const ChatList: React.FC<ChatListProps> = ({
  friends,
  activeChatId,
  onSelectChat,
  lastMessages,
  onOpenAddFriend,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<'all' | 'nearby' | 'relay' | 'online' | 'offline'>('all');

  const filteredFriends = friends.filter((f) => {
    const matchesSearch =
      f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.phone.includes(searchTerm);
    if (!matchesSearch) return false;

    if (filter === 'nearby') return f.status === 'nearby_ble';
    if (filter === 'relay') return f.status === 'out_of_range_relay';
    if (filter === 'online') return f.status === 'online';
    if (filter === 'offline') return f.status === 'disconnected';
    return true;
  });

  const getStatusBadge = (friend: Friend) => {
    switch (friend.status) {
      case 'nearby_ble':
        return (
          <div className="flex items-center gap-1 text-[11px] font-semibold text-amber-400 bg-amber-950/40 border border-amber-500/30 px-2 py-0.5 rounded-full">
            <Radio className="w-3 h-3 animate-pulse text-amber-400" />
            <span>Proche ({friend.distanceMeters}m)</span>
          </div>
        );
      case 'out_of_range_relay':
        return (
          <div className="flex items-center gap-1 text-[11px] font-semibold text-sky-400 bg-sky-950/40 border border-sky-500/30 px-2 py-0.5 rounded-full">
            <Share2 className="w-3 h-3 text-sky-400" />
            <span>Relais ({friend.hopsCount} saut{friend.hopsCount > 1 ? 's' : ''})</span>
          </div>
        );
      case 'online':
        return (
          <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-2 py-0.5 rounded-full">
            <Wifi className="w-3 h-3 text-emerald-400" />
            <span>En ligne</span>
          </div>
        );
      case 'disconnected':
      default:
        return (
          <div className="flex items-center gap-1 text-[11px] font-medium text-neutral-400 bg-neutral-900 border border-neutral-800 px-2 py-0.5 rounded-full">
            <Circle className="w-2 h-2 fill-neutral-500 text-neutral-500" />
            <span>Hors ligne</span>
          </div>
        );
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#0D0D0D] border-r border-[#222222]">
      {/* Recherche et filtres de statut */}
      <div className="p-3 border-b border-[#222222] bg-[#121212]/70 space-y-2.5">
        <div className="relative">
          <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="search-contacts-input"
            type="text"
            placeholder="Rechercher une discussion ou un numéro..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#181818] border border-neutral-800 rounded-lg pl-9 pr-3 py-2 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-[#D4AF37]/60"
          />
        </div>

        {/* Boutons de filtres */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 text-xs no-scrollbar">
          <button
            id="filter-all"
            onClick={() => setFilter('all')}
            className={`px-2.5 py-1 rounded-full whitespace-nowrap transition-colors ${
              filter === 'all'
                ? 'bg-[#D4AF37] text-black font-bold'
                : 'bg-neutral-900 text-neutral-400 hover:text-neutral-200 border border-neutral-800'
            }`}
          >
            Tous ({friends.length})
          </button>
          <button
            id="filter-online"
            onClick={() => setFilter('online')}
            className={`px-2.5 py-1 rounded-full whitespace-nowrap flex items-center gap-1 transition-colors ${
              filter === 'online'
                ? 'bg-emerald-500 text-black font-bold'
                : 'bg-neutral-900 text-emerald-400/80 hover:text-emerald-300 border border-neutral-800'
            }`}
          >
            <Wifi className="w-3 h-3" />
            <span>En ligne</span>
          </button>
          <button
            id="filter-nearby"
            onClick={() => setFilter('nearby')}
            className={`px-2.5 py-1 rounded-full whitespace-nowrap flex items-center gap-1 transition-colors ${
              filter === 'nearby'
                ? 'bg-amber-400 text-black font-bold'
                : 'bg-neutral-900 text-amber-400/80 hover:text-amber-300 border border-neutral-800'
            }`}
          >
            <Radio className="w-3 h-3" />
            <span>Proches (BLE)</span>
          </button>
          <button
            id="filter-relay"
            onClick={() => setFilter('relay')}
            className={`px-2.5 py-1 rounded-full whitespace-nowrap flex items-center gap-1 transition-colors ${
              filter === 'relay'
                ? 'bg-sky-400 text-black font-bold'
                : 'bg-neutral-900 text-sky-400/80 hover:text-sky-300 border border-neutral-800'
            }`}
          >
            <Share2 className="w-3 h-3" />
            <span>Relais</span>
          </button>
          <button
            id="filter-offline"
            onClick={() => setFilter('offline')}
            className={`px-2.5 py-1 rounded-full whitespace-nowrap flex items-center gap-1 transition-colors ${
              filter === 'offline'
                ? 'bg-neutral-300 text-black font-bold'
                : 'bg-neutral-900 text-neutral-400 hover:text-neutral-200 border border-neutral-800'
            }`}
          >
            <WifiOff className="w-3 h-3" />
            <span>Hors ligne</span>
          </button>
        </div>
      </div>

      {/* Bannière d'état maillé */}
      <div className="px-3 py-2 bg-[#171408] border-b border-[#D4AF37]/20 flex items-center justify-between text-xs text-[#EADBB6]">
        <div className="flex items-center gap-2">
          <Zap className="w-3.5 h-3.5 text-[#D4AF37]" />
          <span>Réseau maillé décentralisé sans SIM</span>
        </div>
        <span className="text-[10px] text-[#D4AF37] font-mono">0.0 Ko Données mobiles</span>
      </div>

      {/* Liste des discussions et amis */}
      <div className="flex-1 overflow-y-auto divide-y divide-[#1A1A1A]">
        {filteredFriends.length === 0 ? (
          <div className="p-8 text-center space-y-3">
            <p className="text-xs text-neutral-500">Aucun contact trouvé pour ce filtre.</p>
            <button
              onClick={onOpenAddFriend}
              className="text-xs text-[#D4AF37] hover:underline inline-flex items-center gap-1 font-semibold"
            >
              Inviter un ami par numéro <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        ) : (
          filteredFriends.map((friend) => {
            const msgs = lastMessages[friend.id] || [];
            const lastMsg = msgs[msgs.length - 1];
            const isSelected = activeChatId === friend.id;

            return (
              <div
                key={friend.id}
                id={`chat-item-${friend.id}`}
                onClick={() => onSelectChat(friend.id)}
                className={`p-3.5 cursor-pointer transition-all flex items-start gap-3 relative ${
                  isSelected
                    ? 'bg-[#1C1808] border-l-4 border-[#D4AF37]'
                    : 'hover:bg-[#151515]'
                }`}
              >
                {/* Photo de profil avec anneau d'état */}
                <div className="relative shrink-0">
                  <img
                    src={friend.avatar}
                    alt={friend.name}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-full object-cover border border-neutral-800"
                  />
                  {friend.status === 'nearby_ble' && (
                    <span
                      className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-amber-400 border-2 border-[#0D0D0D] rounded-full shadow"
                      title="Proche (Bluetooth BLE)"
                    />
                  )}
                  {friend.status === 'out_of_range_relay' && (
                    <span
                      className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-sky-400 border-2 border-[#0D0D0D] rounded-full shadow"
                      title="Connecté par relais"
                    />
                  )}
                  {friend.status === 'online' && (
                    <span
                      className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#0D0D0D] rounded-full shadow"
                      title="En ligne"
                    />
                  )}
                  {friend.status === 'disconnected' && (
                    <span
                      className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-neutral-600 border-2 border-[#0D0D0D] rounded-full shadow"
                      title="Hors ligne"
                    />
                  )}
                </div>

                {/* Contenu discussion */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline justify-between mb-1">
                    <h3 className="text-sm font-semibold text-neutral-100 truncate flex items-center gap-1.5">
                      {friend.name}
                      {friend.status === 'nearby_ble' && (
                        <span className="text-[10px] text-amber-400 font-mono">
                          ⚡ {friend.distanceMeters}m
                        </span>
                      )}
                    </h3>
                    <span className="text-[11px] text-neutral-500 whitespace-nowrap ml-2">
                      {lastMsg?.timestamp || '12:00'}
                    </span>
                  </div>

                  {/* Aperçu du dernier message */}
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <div className="text-xs text-neutral-400 truncate flex-1">
                      {lastMsg ? (
                        lastMsg.type === 'voice' ? (
                          <span className="text-[#D4AF37] flex items-center gap-1">
                            🎤 Note vocale ({lastMsg.voiceDurationSeconds || 5}s)
                          </span>
                        ) : lastMsg.type === 'image' ? (
                          <span className="text-sky-400 flex items-center gap-1">
                            📷 Photo chiffrée
                          </span>
                        ) : (
                          <span>{lastMsg.content}</span>
                        )
                      ) : (
                        <span className="italic text-neutral-600">Nouvelle connexion établie</span>
                      )}
                    </div>

                    {friend.unreadCount > 0 && (
                      <span className="px-1.5 py-0.5 rounded-full bg-[#D4AF37] text-black text-[10px] font-bold shrink-0">
                        {friend.unreadCount}
                      </span>
                    )}
                  </div>

                  {/* Badge d'état & détails de relais */}
                  <div className="flex items-center justify-between text-[10px]">
                    {getStatusBadge(friend)}
                    {friend.status === 'out_of_range_relay' && friend.relayNodeName && (
                      <span className="text-neutral-500 text-[10px] truncate max-w-[130px]" title={`Acheminé via ${friend.relayNodeName}`}>
                        ↳ {friend.relayNodeName}
                      </span>
                    )}
                    {friend.status === 'nearby_ble' && friend.rssi && (
                      <span className="text-neutral-500 font-mono text-[10px]">
                        Signal: {friend.rssi} dBm
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Bouton bas : Ajouter un ami */}
      <div className="p-3 bg-[#111111] border-t border-[#222222]">
        <button
          id="btn-add-contact-bottom"
          onClick={onOpenAddFriend}
          className="w-full py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-[#D4AF37]/30 hover:border-[#D4AF37] text-xs font-semibold text-[#D4AF37] flex items-center justify-center gap-2 transition-all shadow-sm"
        >
          <span>Ajouter un ami (Consentement mutuel)</span>
          <span className="text-base leading-none">+</span>
        </button>
      </div>
    </div>
  );
};
