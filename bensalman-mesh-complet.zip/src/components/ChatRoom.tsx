import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Mic,
  Image as ImageIcon,
  ShieldCheck,
  Radio,
  Wifi,
  Share2,
  Check,
  CheckCheck,
  Play,
  Pause,
  ArrowLeft,
  Lock,
  Compass,
  Eye,
  WifiOff
} from 'lucide-react';
import { Friend, ChatMessage, UserProfile } from '../types';
import { simulateEncrypt, getSecurityFingerprint } from '../utils/crypto';

interface ChatRoomProps {
  friend: Friend;
  user: UserProfile;
  messages: ChatMessage[];
  onSendMessage: (content: string, type: 'text' | 'voice' | 'image', extra?: { voiceDurationSeconds?: number; imageCaption?: string }) => void;
  onBack: () => void;
  onOpenMeshTopology: () => void;
}

export const ChatRoom: React.FC<ChatRoomProps> = ({
  friend,
  user,
  messages,
  onSendMessage,
  onBack,
  onOpenMeshTopology,
}) => {
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [audioPlayingId, setAudioPlayingId] = useState<string | null>(null);
  const [showCryptoModal, setShowCryptoModal] = useState(false);
  const [previewCiphertext, setPreviewCiphertext] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recordIntervalRef = useRef<any>(null);

  // Défilement automatique vers le bas
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Minuteur d'enregistrement vocal
  useEffect(() => {
    if (isRecording) {
      setRecordSeconds(0);
      recordIntervalRef.current = setInterval(() => {
        setRecordSeconds((s) => s + 1);
      }, 1000);
    } else {
      if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);
    }
    return () => {
      if (recordIntervalRef.current) clearInterval(recordIntervalRef.current);
    };
  }, [isRecording]);

  const handleSendText = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim(), 'text');
    setInputText('');
  };

  const handleStartVoice = async () => {
    setIsRecording(true);
  };

  const handleStopVoice = (cancel = false) => {
    setIsRecording(false);
    if (!cancel && recordSeconds > 0) {
      onSendMessage('Note vocale chiffrée', 'voice', { voiceDurationSeconds: recordSeconds || 3 });
    }
    setRecordSeconds(0);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      onSendMessage(dataUrl, 'image', { imageCaption: file.name });
    };
    reader.readAsDataURL(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const toggleAudioPlay = (msgId: string) => {
    if (audioPlayingId === msgId) {
      setAudioPlayingId(null);
    } else {
      setAudioPlayingId(msgId);
      setTimeout(() => {
        setAudioPlayingId((curr) => (curr === msgId ? null : curr));
      }, 6000);
    }
  };

  const securityFingerprint = getSecurityFingerprint(user.publicKey, friend.publicKey);

  return (
    <div className="h-full flex flex-col bg-[#0A0A0A] relative">
      {/* En-tête de la discussion */}
      <div className="bg-[#121212] border-b border-[#242424] px-4 py-2.5 flex items-center justify-between gap-3 z-10">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onBack}
            className="md:hidden p-1.5 -ml-1 text-neutral-400 hover:text-white"
            title="Retour à la liste"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="relative shrink-0 cursor-pointer" onClick={() => setShowCryptoModal(true)}>
            <img
              src={friend.avatar}
              alt={friend.name}
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-full object-cover border border-[#D4AF37]/30"
            />
            <span
              className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#121212] ${
                friend.status === 'nearby_ble'
                  ? 'bg-amber-400'
                  : friend.status === 'out_of_range_relay'
                  ? 'bg-sky-400'
                  : friend.status === 'online'
                  ? 'bg-emerald-500'
                  : 'bg-neutral-600'
              }`}
            />
          </div>

          <div className="min-w-0 cursor-pointer" onClick={() => setShowCryptoModal(true)}>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-neutral-100 truncate">{friend.name}</h2>
              <span className="text-xs text-neutral-500 hidden sm:inline font-mono">{friend.phone}</span>
            </div>

            {/* Statut avec Distance / Relais / En ligne / Hors ligne */}
            <div className="flex items-center gap-1.5 text-xs">
              {friend.status === 'nearby_ble' && (
                <span className="text-amber-400 flex items-center gap-1 font-medium">
                  <Radio className="w-3 h-3 animate-pulse" />
                  <span>Proche (BLE ~{friend.distanceMeters}m)</span>
                </span>
              )}
              {friend.status === 'out_of_range_relay' && (
                <span className="text-sky-400 flex items-center gap-1 font-medium truncate">
                  <Share2 className="w-3 h-3" />
                  <span>Relais : {friend.relayNodeName || '1 saut maillé'}</span>
                </span>
              )}
              {friend.status === 'online' && (
                <span className="text-emerald-400 flex items-center gap-1 font-medium">
                  <Wifi className="w-3 h-3" />
                  <span>En ligne (Cloud)</span>
                </span>
              )}
              {friend.status === 'disconnected' && (
                <span className="text-neutral-400 flex items-center gap-1 font-medium">
                  <WifiOff className="w-3 h-3" />
                  <span>Hors ligne</span>
                </span>
              )}
              <span className="text-neutral-600">•</span>
              <span className="text-[#D4AF37] text-[11px] flex items-center gap-0.5">
                <Lock className="w-2.5 h-2.5" /> Chiffrement E2E actif
              </span>
            </div>
          </div>
        </div>

        {/* Boutons d'action droite */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenMeshTopology}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700 hover:border-[#D4AF37]/40 transition-all"
            title="Visualiser le cheminement des paquets"
          >
            <Compass className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Route Relais</span>
          </button>

          <button
            onClick={() => setShowCryptoModal(true)}
            className="p-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-[#D4AF37] border border-[#D4AF37]/30"
            title="Vérifier l'empreinte de sécurité et les clés"
          >
            <ShieldCheck className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Bannière de transport réseau */}
      <div className="px-4 py-1.5 bg-[#141209] border-b border-[#D4AF37]/20 flex items-center justify-between text-[11px] text-neutral-300">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5">
          <span className="text-neutral-500 shrink-0">Transport :</span>
          {friend.status === 'nearby_ble' ? (
            <span className="flex items-center gap-1 text-amber-400 font-mono">
              <span>Émetteur (Vous)</span> ➔ <span className="text-xs">⚡ BLE (P2P direct)</span> ➔ <span>{friend.name}</span>
            </span>
          ) : friend.status === 'out_of_range_relay' ? (
            <span className="flex items-center gap-1 text-sky-300 font-mono">
              <span>Émetteur (Vous)</span> ➔ <span className="text-amber-400 text-xs">BLE</span> ➔{' '}
              <span className="bg-sky-950 px-1 py-0.2 rounded border border-sky-600/40 text-sky-300 font-bold">
                {friend.relayNodeName?.split(' ')[0] || 'Relais'}
              </span>{' '}
              ➔ <span className="text-sky-400 text-xs">Wi-Fi Direct</span> ➔ <span>{friend.name}</span>
            </span>
          ) : friend.status === 'online' ? (
            <span className="flex items-center gap-1 text-emerald-400 font-mono">
              <span>Émetteur (Vous)</span> ➔ <span className="text-xs">Cloud Firebase</span> ➔ <span>{friend.name}</span>
            </span>
          ) : (
            <span className="flex items-center gap-1 text-neutral-400 font-mono">
              <span>Émetteur (Vous)</span> ➔ <span className="text-xs">Hors ligne (En attente d'un nœud relais)</span>
            </span>
          )}
        </div>

        <button
          onClick={() => {
            const sampleCipher = simulateEncrypt(
              messages[messages.length - 1]?.content || 'Test BENSALMAN',
              friend.publicKey
            );
            setPreviewCiphertext(sampleCipher);
          }}
          className="text-[10px] text-[#D4AF37] hover:underline shrink-0 ml-2 font-mono flex items-center gap-1"
        >
          <Eye className="w-3 h-3" /> Voir données chiffrées
        </button>
      </div>

      {/* Fil des messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#0A0A0A]">
        {/* Avertissement de sécurité */}
        <div className="max-w-md mx-auto my-2 p-2.5 rounded-xl bg-[#141414] border border-[#2B2819] text-center space-y-1">
          <div className="flex items-center justify-center gap-1.5 text-xs text-[#D4AF37] font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Protocole Maillé Sécurisé BENSALMAN</span>
          </div>
          <p className="text-[11px] text-neutral-400 leading-relaxed">
            Les messages sont chiffrés avec la clé publique de {friend.name}. Si le message transite par d'autres téléphones relais, aucun tiers ne peut lire son contenu.
          </p>
          <div className="text-[10px] text-neutral-500 font-mono">
            Empreinte de sécurité : {securityFingerprint}
          </div>
        </div>

        {/* Liste des messages */}
        {messages.map((msg) => {
          const isMe = msg.senderId === user.id;

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[70%] rounded-2xl p-3 shadow-md relative ${
                  isMe
                    ? 'bg-gradient-to-br from-[#292208] to-[#1C1605] border border-[#D4AF37]/35 text-neutral-100 rounded-tr-none'
                    : 'bg-[#181818] border border-neutral-800 text-neutral-100 rounded-tl-none'
                }`}
              >
                {/* Message Image */}
                {msg.type === 'image' && (
                  <div className="mb-2 rounded-lg overflow-hidden border border-black/40">
                    <img
                      src={msg.content}
                      alt={msg.imageCaption || 'Photo'}
                      className="w-full max-h-64 object-cover cursor-pointer hover:scale-105 transition-transform"
                    />
                    {msg.imageCaption && (
                      <p className="text-xs text-neutral-300 mt-1 px-1">{msg.imageCaption}</p>
                    )}
                  </div>
                )}

                {/* Message Note Vocale */}
                {msg.type === 'voice' && (
                  <div className="flex items-center gap-3 py-1 min-w-[200px]">
                    <button
                      onClick={() => toggleAudioPlay(msg.id)}
                      className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
                        audioPlayingId === msg.id
                          ? 'bg-[#D4AF37] text-black shadow-[0_0_12px_rgba(212,175,55,0.4)]'
                          : 'bg-neutral-800 hover:bg-neutral-700 text-[#D4AF37]'
                      }`}
                      title={audioPlayingId === msg.id ? 'Pause' : 'Écouter la note vocale'}
                    >
                      {audioPlayingId === msg.id ? (
                        <Pause className="w-4 h-4 fill-current" />
                      ) : (
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      )}
                    </button>

                    {/* Simulation d'ondes sonores */}
                    <div className="flex-1 flex items-center gap-0.5 h-6">
                      {[40, 75, 50, 90, 30, 80, 60, 95, 45, 70, 35, 85, 55, 65, 40].map((h, i) => (
                        <span
                          key={i}
                          className={`w-1 rounded-full transition-all duration-300 ${
                            audioPlayingId === msg.id ? 'bg-[#D4AF37] animate-pulse' : 'bg-neutral-600'
                          }`}
                          style={{
                            height: `${audioPlayingId === msg.id ? Math.max(20, (h * (i % 2 === 0 ? 1.2 : 0.8)) % 100) : h}%`,
                          }}
                        />
                      ))}
                    </div>

                    <span className="text-[11px] font-mono text-neutral-400 shrink-0">
                      0:0{msg.voiceDurationSeconds || 5}
                    </span>
                  </div>
                )}

                {/* Message Texte */}
                {msg.type === 'text' && (
                  <p className="text-sm leading-relaxed whitespace-pre-wrap select-text">
                    {msg.content}
                  </p>
                )}

                {/* Pied du message : Horodatage, badge de transport, coches de remise */}
                <div className="flex items-center justify-end gap-1.5 mt-1 text-[10px] text-neutral-400 select-none">
                  {msg.transport === 'MESH_RELAY' && (
                    <span className="text-sky-400 flex items-center gap-0.5 font-mono text-[9px] bg-sky-950/60 px-1 rounded">
                      <Share2 className="w-2.5 h-2.5" /> Relais
                    </span>
                  )}
                  {msg.transport === 'BLE_DIRECT' && (
                    <span className="text-amber-400 flex items-center gap-0.5 font-mono text-[9px] bg-amber-950/60 px-1 rounded">
                      <Radio className="w-2.5 h-2.5" /> BLE
                    </span>
                  )}
                  {msg.transport === 'INTERNET_FIREBASE' && (
                    <span className="text-emerald-400 flex items-center gap-0.5 font-mono text-[9px] bg-emerald-950/60 px-1 rounded">
                      <Wifi className="w-2.5 h-2.5" /> En ligne
                    </span>
                  )}

                  <span>{msg.timestamp}</span>

                  {isMe && (
                    <span className="ml-0.5">
                      {msg.deliveryStatus === 'sending' && (
                        <span className="text-neutral-500" title="Envoi en cours...">⏳</span>
                      )}
                      {msg.deliveryStatus === 'relayed' && (
                        <Check className="w-3 h-3 text-neutral-400" title="Relayé au nœud intermédiaire" />
                      )}
                      {msg.deliveryStatus === 'delivered' && (
                        <CheckCheck className="w-3.5 h-3.5 text-neutral-400" title="Délivré sur le terminal" />
                      )}
                      {msg.deliveryStatus === 'read' && (
                        <CheckCheck className="w-3.5 h-3.5 text-[#D4AF37]" title="Lu par le destinataire" />
                      )}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Bandeau d'enregistrement vocal */}
      {isRecording && (
        <div className="p-3 bg-red-950/80 border-t border-red-500/40 flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-2 text-red-300 text-xs font-semibold">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
            <span>Enregistrement audio local en cours...</span>
            <span className="font-mono text-white text-sm ml-2">0:0{recordSeconds}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleStopVoice(true)}
              className="px-2.5 py-1 rounded-lg bg-neutral-900 text-xs text-neutral-400 hover:text-white"
            >
              Annuler
            </button>
            <button
              onClick={() => handleStopVoice(false)}
              className="px-3 py-1 rounded-lg bg-red-600 text-xs font-bold text-white shadow-md hover:bg-red-500"
            >
              Envoyer la note
            </button>
          </div>
        </div>
      )}

      {/* Barre de saisie de message */}
      <div className="p-3 bg-[#121212] border-t border-[#222222]">
        <form onSubmit={handleSendText} className="flex items-center gap-2 max-w-5xl mx-auto">
          {/* Sélectionner une photo */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*"
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-[#D4AF37] border border-neutral-800 transition-colors"
            title="Joindre une photo chiffrée"
          >
            <ImageIcon className="w-5 h-5" />
          </button>

          {/* Champ texte */}
          <div className="flex-1 relative">
            <input
              id="message-input-text"
              type="text"
              placeholder={
                friend.status === 'out_of_range_relay'
                  ? `Message pour ${friend.name} (acheminement par relais)...`
                  : friend.status === 'disconnected'
                  ? `Message pour ${friend.name} (en attente de connexion)...`
                  : `Message chiffré pour ${friend.name}...`
              }
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full bg-[#1A1A1A] border border-neutral-800 rounded-xl px-4 py-2.5 text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-[#D4AF37]/60"
            />
          </div>

          {/* Bouton d'envoi ou enregistrement vocal */}
          {inputText.trim().length > 0 ? (
            <button
              id="btn-send-message"
              type="submit"
              className="p-2.5 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B38C22] text-black font-bold shadow-[0_0_15px_rgba(212,175,55,0.3)] hover:brightness-110 active:scale-95 transition-all"
              title="Envoyer le message"
            >
              <Send className="w-5 h-5" />
            </button>
          ) : (
            <button
              id="btn-record-voice"
              type="button"
              onClick={handleStartVoice}
              className={`p-2.5 rounded-xl border transition-all ${
                isRecording
                  ? 'bg-red-600 text-white border-red-500 animate-pulse'
                  : 'bg-neutral-900 hover:bg-neutral-800 text-[#D4AF37] border-neutral-800 hover:border-[#D4AF37]/50'
              }`}
              title="Enregistrer une note vocale"
            >
              <Mic className="w-5 h-5" />
            </button>
          )}
        </form>
      </div>

      {/* Fenêtre modale d'inspection cryptographique */}
      {showCryptoModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141414] border border-[#D4AF37]/40 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#2A2A2A]">
              <div className="flex items-center gap-2 text-[#D4AF37] font-royal font-bold text-base">
                <ShieldCheck className="w-5 h-5" />
                <span>Chiffrement de bout en bout BENSALMAN</span>
              </div>
              <button
                onClick={() => setShowCryptoModal(false)}
                className="text-neutral-400 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-neutral-300">
              <div className="p-3 bg-black/60 rounded-xl border border-neutral-800 space-y-2">
                <div className="text-neutral-400 font-semibold">Numéro de sécurité vérifié :</div>
                <div className="text-lg font-mono text-[#D4AF37] tracking-wider text-center py-1 bg-neutral-900 rounded-lg border border-[#D4AF37]/20">
                  {securityFingerprint}
                </div>
                <p className="text-[11px] text-neutral-500">
                  Comparez ce code avec {friend.name} pour garantir qu'aucune écoute homme-du-milieu n'est possible sur le réseau maillé.
                </p>
              </div>

              <div className="space-y-1">
                <span className="text-neutral-500">Clé publique de {friend.name} (X25519) :</span>
                <div className="font-mono text-[10px] text-neutral-400 break-all bg-neutral-900 p-2 rounded-lg border border-neutral-800">
                  {friend.publicKey}
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-neutral-500">Votre clé publique locale :</span>
                <div className="font-mono text-[10px] text-neutral-400 break-all bg-neutral-900 p-2 rounded-lg border border-neutral-800">
                  {user.publicKey}
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-emerald-300 text-[11px] leading-relaxed">
                ✓ Algorithmes : AES-256-GCM (Contenu), X25519 (Échange de clés), Ed25519 (Signatures des nœuds relais).
              </div>
            </div>

            <button
              onClick={() => setShowCryptoModal(false)}
              className="w-full py-2.5 rounded-xl bg-[#D4AF37] text-black font-bold text-xs hover:brightness-110"
            >
              Fermer la vérification
            </button>
          </div>
        </div>
      )}

      {/* Modale d'aperçu des données brutes chiffrées */}
      {previewCiphertext && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#141414] border border-neutral-700 rounded-2xl max-w-lg w-full p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <span className="text-sm font-bold text-[#D4AF37] flex items-center gap-2">
                <Lock className="w-4 h-4" /> Données brutes chiffrées en transit
              </span>
              <button
                onClick={() => setPreviewCiphertext(null)}
                className="text-neutral-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-neutral-400">
              Voici exactement ce que voient les nœuds relais intermédiaires (comme le téléphone de Karim) lors de l'acheminement sans fil :
            </p>

            <div className="bg-black p-3 rounded-xl border border-neutral-800 font-mono text-[11px] text-amber-300 break-all select-all">
              {previewCiphertext}
            </div>

            <p className="text-[11px] text-neutral-500">
              Totalement illisible sans la clé privée du terminal destinataire.
            </p>

            <button
              onClick={() => setPreviewCiphertext(null)}
              className="w-full py-2 rounded-xl bg-neutral-800 text-xs font-semibold text-neutral-200 hover:bg-neutral-700"
            >
              Fermer
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
