import React from 'react';
import { Sparkles, ArrowRightLeft } from 'lucide-react';
import { Friend } from '../types';

interface DeviceSwitcherProps {
  currentRole: 'salman' | 'karim' | 'amina';
  onSwitchRole: (role: 'salman' | 'karim' | 'amina') => void;
  onSimulateIncomingReply: () => void;
  activeFriend: Friend | undefined;
}

export const DeviceSwitcher: React.FC<DeviceSwitcherProps> = ({
  currentRole,
  onSwitchRole,
  onSimulateIncomingReply,
  activeFriend,
}) => {
  return (
    <div className="bg-[#141208] border-b border-[#D4AF37]/30 px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs">
      <div className="flex items-center gap-2">
        <span className="text-[11px] font-bold text-[#D4AF37] uppercase tracking-wider flex items-center gap-1">
          <Sparkles className="w-3 h-3" />
          <span>Simulateur multi-terminaux :</span>
        </span>

        <div className="flex items-center bg-[#0D0D0D] p-1 rounded-lg border border-neutral-800">
          <button
            onClick={() => onSwitchRole('salman')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
              currentRole === 'salman'
                ? 'bg-[#D4AF37] text-black font-bold shadow'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="Terminal émetteur principal"
          >
            📱 Salman (Émetteur)
          </button>
          <button
            onClick={() => onSwitchRole('karim')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
              currentRole === 'karim'
                ? 'bg-amber-400 text-black font-bold shadow'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="Point de vue du nœud relais Bluetooth intermédiaire"
          >
            📡 Karim (Relais BLE 4m)
          </button>
          <button
            onClick={() => onSwitchRole('amina')}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
              currentRole === 'amina'
                ? 'bg-sky-400 text-black font-bold shadow'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="Point de vue du destinataire lointain à 42m"
          >
            🎯 Amina (Destinataire 42m)
          </button>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={onSimulateIncomingReply}
          className="px-3 py-1 rounded-lg bg-[#1E1906] hover:bg-[#2A2308] border border-[#D4AF37]/40 text-[#D4AF37] font-semibold text-[11px] flex items-center gap-1.5 transition-all shadow-sm"
          title="Simuler une réponse chiffrée reçue via le réseau maillé"
        >
          <ArrowRightLeft className="w-3 h-3" />
          <span>Simuler une réponse réseau</span>
        </button>
      </div>
    </div>
  );
};
