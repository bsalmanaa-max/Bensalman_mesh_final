import React, { useState } from 'react';
import { UserProfile } from '../types';
import { ShieldCheck, Radio, Wifi, Battery, Smartphone, KeyRound, Check, RefreshCw } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onUpdateUser: (updated: Partial<UserProfile>) => void;
  onResetData: () => void;
  onOpenAuth: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  user,
  onUpdateUser,
  onResetData,
  onOpenAuth,
}) => {
  const [copiedKey, setCopiedKey] = useState(false);

  if (!isOpen) return null;

  const handleCopyKey = () => {
    navigator.clipboard.writeText(user.publicKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#121212] border border-[#D4AF37]/40 rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        <div className="px-6 py-4 border-b border-[#242424] flex items-center justify-between bg-[#161616]">
          <div className="flex items-center gap-2.5">
            <Smartphone className="w-5 h-5 text-[#D4AF37]" />
            <h2 className="text-base font-bold text-white font-royal">
              Paramètres & Statut Matériel
            </h2>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white">✕</button>
        </div>

        <div className="p-6 overflow-y-auto space-y-5 text-xs text-neutral-300">
          {/* User Card */}
          <div className="p-4 rounded-2xl bg-[#181818] border border-neutral-800 flex items-center gap-4">
            <img
              src={user.avatar}
              alt={user.name}
              referrerPolicy="no-referrer"
              className="w-14 h-14 rounded-full object-cover border-2 border-[#D4AF37]"
            />
            <div className="min-w-0 flex-1">
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span>{user.name}</span>
                <span className="text-[10px] bg-[#D4AF37] text-black px-1.5 py-0.2 rounded font-black">
                  👑
                </span>
              </div>
              <div className="text-neutral-400 font-mono text-xs">{user.phone}</div>
              <div className="text-[11px] text-[#D4AF37] mt-0.5">{user.statusMessage}</div>
            </div>
            <button
              onClick={onOpenAuth}
              className="text-[11px] px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-[#D4AF37] border border-neutral-700"
            >
              Modifier
            </button>
          </div>

          {/* Radio Radios Toggles */}
          <div className="space-y-3">
            <h3 className="text-xs uppercase font-bold text-neutral-400 tracking-wider">
              Radios Physiques Mesh
            </h3>

            <div className="p-3 bg-[#161616] rounded-xl border border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Radio className="w-4 h-4 text-amber-400" />
                <div>
                  <div className="font-semibold text-white">Bluetooth Low Energy (BLE 5.2)</div>
                  <div className="text-[11px] text-neutral-500">Découverte de pairs à courte portée (0 - 30m)</div>
                </div>
              </div>
              <input
                type="checkbox"
                checked={user.bleEnabled}
                onChange={(e) => onUpdateUser({ bleEnabled: e.target.checked })}
                className="w-4 h-4 accent-[#D4AF37] cursor-pointer"
              />
            </div>

            <div className="p-3 bg-[#161616] rounded-xl border border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Wifi className="w-4 h-4 text-sky-400" />
                <div>
                  <div className="font-semibold text-white">Wi-Fi Direct P2P (High Throughput)</div>
                  <div className="text-[11px] text-neutral-500">Transfert de vocaux et images sans routeur</div>
                </div>
              </div>
              <input
                type="checkbox"
                checked={user.wifiDirectEnabled}
                onChange={(e) => onUpdateUser({ wifiDirectEnabled: e.target.checked })}
                className="w-4 h-4 accent-[#D4AF37] cursor-pointer"
              />
            </div>

            <div className="p-3 bg-[#161616] rounded-xl border border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                <div>
                  <div className="font-semibold text-white">Participer au routage relais (Mesh Hop)</div>
                  <div className="text-[11px] text-neutral-500">Aide la communauté en relayant les paquets chiffrés</div>
                </div>
              </div>
              <input
                type="checkbox"
                checked={user.isRelayActive}
                onChange={(e) => onUpdateUser({ isRelayActive: e.target.checked })}
                className="w-4 h-4 accent-[#D4AF37] cursor-pointer"
              />
            </div>
          </div>

          {/* Cryptography section */}
          <div className="p-3.5 bg-black rounded-xl border border-neutral-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-neutral-300 flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-[#D4AF37]" />
                Clé Publique E2E Locale (X25519)
              </span>
              <button
                onClick={handleCopyKey}
                className="text-[10px] text-[#D4AF37] hover:underline flex items-center gap-1"
              >
                {copiedKey ? <Check className="w-3 h-3 text-emerald-400" /> : null}
                <span>{copiedKey ? 'Copié' : 'Copier'}</span>
              </button>
            </div>
            <div className="font-mono text-[10px] text-neutral-400 break-all bg-neutral-900 p-2 rounded border border-neutral-800">
              {user.publicKey}
            </div>
          </div>

          {/* Reset simulation */}
          <div className="pt-2 border-t border-neutral-800 flex justify-between items-center">
            <span className="text-neutral-500 text-[11px]">Réinitialiser les messages de démo</span>
            <button
              onClick={onResetData}
              className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs flex items-center gap-1"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Réinitialiser</span>
            </button>
          </div>
        </div>

        <div className="px-6 py-3 border-t border-[#242424] bg-[#161616] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#D4AF37] text-black font-bold text-xs hover:brightness-110"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
