import React, { useState, useEffect } from 'react';
import { Share2, Radio, Zap, ShieldCheck, Play, Smartphone, Activity } from 'lucide-react';
import { MESH_TOPOLOGY_NODES } from '../data/mockData';
import { MeshTopologyNode } from '../types';

interface MeshTopologyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MeshTopologyModal: React.FC<MeshTopologyModalProps> = ({ isOpen, onClose }) => {
  const [nodes] = useState<MeshTopologyNode[]>(MESH_TOPOLOGY_NODES);
  const [isSimulatingPacket, setIsSimulatingPacket] = useState(false);
  const [packetProgress, setPacketProgress] = useState(0); // 0 à 100
  const [currentHop, setCurrentHop] = useState<'idle' | 'hop1' | 'hop2' | 'delivered'>('idle');
  const [logMessages, setLogMessages] = useState<string[]>([
    'Réseau maillé initialisé.',
    'Nœud Émetteur (Salman) connecté à Nœud Relais (Karim) en BLE direct (4m, RSSI -62 dBm).',
    'Nœud Relais (Karim) en écoute pour Nœud Destinataire (Amina).',
  ]);

  useEffect(() => {
    let interval: any;
    if (isSimulatingPacket) {
      interval = setInterval(() => {
        setPacketProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsSimulatingPacket(false);
            setCurrentHop('delivered');
            setLogMessages((logs) => [
              `[${new Date().toLocaleTimeString()}] ✅ Paquet délivré avec succès à Amina K. (Zéro internet utilisé).`,
              ...logs,
            ]);
            return 100;
          }

          const next = prev + 5;
          if (next > 45 && next < 55) {
            setCurrentHop('hop2');
            setLogMessages((logs) => [
              `[${new Date().toLocaleTimeString()}] 📡 Karim Z. (Relais) a reçu le paquet chiffré et le relaie via Wi-Fi Direct vers Amina K.`,
              ...logs,
            ]);
          }
          return next;
        });
      }, 120);
    }
    return () => clearInterval(interval);
  }, [isSimulatingPacket]);

  if (!isOpen) return null;

  const triggerPacketSimulation = () => {
    setIsSimulatingPacket(true);
    setPacketProgress(0);
    setCurrentHop('hop1');
    setLogMessages((logs) => [
      `[${new Date().toLocaleTimeString()}] 🚀 Émission d'un paquet chiffré (AES-256) depuis l'Émetteur (Salman) vers Karim (Relais)...`,
      ...logs,
    ]);
  };

  // Coordonnées des nœuds
  const nodeA = nodes.find((n) => n.id === 'user_salman') || nodes[0];
  const nodeB = nodes.find((n) => n.id === 'friend_karim') || nodes[1];
  const nodeC = nodes.find((n) => n.id === 'friend_amina') || nodes[2];

  // Calcul position du paquet
  let packetX = nodeA.x;
  let packetY = nodeA.y;

  if (packetProgress <= 50) {
    const ratio = packetProgress / 50;
    packetX = nodeA.x + (nodeB.x - nodeA.x) * ratio;
    packetY = nodeA.y + (nodeB.y - nodeA.y) * ratio;
  } else {
    const ratio = (packetProgress - 50) / 50;
    packetX = nodeB.x + (nodeC.x - nodeB.x) * ratio;
    packetY = nodeB.y + (nodeC.y - nodeB.y) * ratio;
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#121212] border border-[#D4AF37]/40 rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-[0_0_40px_rgba(212,175,55,0.15)]">
        {/* En-tête */}
        <div className="px-6 py-4 border-b border-[#242424] flex items-center justify-between bg-[#161616]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#1E1A0A] border border-[#D4AF37]/50 flex items-center justify-center text-[#D4AF37]">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold font-royal text-[#E5E5E5] flex items-center gap-2">
                <span>Topologie du Réseau Maillé BENSALMAN</span>
                <span className="text-[#D4AF37] text-sm">👑</span>
              </h2>
              <p className="text-xs text-neutral-400">
                Simulation en direct du routage multi-sauts (Émetteur ➔ Relais ➔ Destinataire) sans SIM ni connexion Internet
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 flex items-center justify-center text-sm font-bold"
          >
            ✕
          </button>
        </div>

        {/* Corps */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* Panneaux récapitulatifs */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-2xl bg-[#181818] border border-neutral-800 space-y-1">
              <span className="text-[11px] text-neutral-400 uppercase tracking-wider font-semibold">
                Nœuds Découverts
              </span>
              <div className="text-xl font-bold text-white flex items-center justify-between">
                <span>{nodes.length} Nœuds</span>
                <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
              </div>
              <p className="text-[11px] text-neutral-500">Portée par saut : ~50-100m en extérieur</p>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#181818] border border-neutral-800 space-y-1">
              <span className="text-[11px] text-neutral-400 uppercase tracking-wider font-semibold">
                Nœud Relais Intermédiaire
              </span>
              <div className="text-xl font-bold text-[#D4AF37] flex items-center justify-between">
                <span>Karim Z.</span>
                <span className="text-xs bg-[#D4AF37]/20 text-[#D4AF37] px-2 py-0.5 rounded-full border border-[#D4AF37]/40">
                  Relais actif
                </span>
              </div>
              <p className="text-[11px] text-neutral-500">Transmet les paquets sans pouvoir les déchiffrer</p>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#181818] border border-neutral-800 space-y-1">
              <span className="text-[11px] text-neutral-400 uppercase tracking-wider font-semibold">
                Protocole Physique
              </span>
              <div className="text-xl font-bold text-sky-400 flex items-center justify-between">
                <span>BLE 5.2 + Wi-Fi Direct</span>
                <Zap className="w-4 h-4 text-sky-400" />
              </div>
              <p className="text-[11px] text-neutral-500">Liaison locale haute vitesse sans routeur</p>
            </div>
          </div>

          {/* Graphe visuel interactif */}
          <div className="relative bg-[#0A0A0A] rounded-2xl border border-neutral-800 p-4 overflow-hidden min-h-[340px]">
            {/* Grille d'arrière-plan */}
            <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#D4AF37_1px,transparent_1px)] [background-size:24px_24px]" />

            {/* Lignes SVG */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              {/* Ligne Émetteur -> Relais */}
              <line
                x1={nodeA.x}
                y1={nodeA.y}
                x2={nodeB.x}
                y2={nodeB.y}
                stroke={isSimulatingPacket && packetProgress <= 50 ? '#D4AF37' : '#333333'}
                strokeWidth="2.5"
                strokeDasharray={isSimulatingPacket && packetProgress <= 50 ? '6 4' : undefined}
                className={isSimulatingPacket && packetProgress <= 50 ? 'animate-pulse' : ''}
              />
              {/* Ligne Relais -> Destinataire */}
              <line
                x1={nodeB.x}
                y1={nodeB.y}
                x2={nodeC.x}
                y2={nodeC.y}
                stroke={isSimulatingPacket && packetProgress > 50 ? '#38BDF8' : '#333333'}
                strokeWidth="2.5"
                strokeDasharray={isSimulatingPacket && packetProgress > 50 ? '6 4' : undefined}
                className={isSimulatingPacket && packetProgress > 50 ? 'animate-pulse' : ''}
              />

              {/* Autres liaisons */}
              {nodes.map((node) =>
                node.connections.map((targetId) => {
                  const target = nodes.find((n) => n.id === targetId);
                  if (!target || (node.id === nodeA.id && target.id === nodeB.id) || (node.id === nodeB.id && target.id === nodeC.id)) {
                    return null;
                  }
                  return (
                    <line
                      key={`${node.id}-${targetId}`}
                      x1={node.x}
                      y1={node.y}
                      x2={target.x}
                      y2={target.y}
                      stroke="#222222"
                      strokeWidth="1.5"
                      strokeDasharray="4 4"
                    />
                  );
                })
              )}

              {/* Paquet animé en transit */}
              {isSimulatingPacket && (
                <g>
                  <circle
                    cx={packetX}
                    cy={packetY}
                    r="9"
                    fill="#D4AF37"
                    className="animate-ping opacity-75"
                  />
                  <circle
                    cx={packetX}
                    cy={packetY}
                    r="6"
                    fill="#FFD700"
                    stroke="#FFFFFF"
                    strokeWidth="2"
                  />
                </g>
              )}
            </svg>

            {/* Rendu des nœuds */}
            {nodes.map((node) => {
              const isSelectedHop =
                (currentHop === 'hop1' && node.id === nodeA.id) ||
                (currentHop === 'hop2' && node.id === nodeB.id) ||
                (currentHop === 'delivered' && node.id === nodeC.id);

              return (
                <div
                  key={node.id}
                  style={{ left: `${node.x - 55}px`, top: `${node.y - 45}px` }}
                  className={`absolute w-32 flex flex-col items-center select-none transition-all duration-300 z-10`}
                >
                  <div
                    className={`w-14 h-14 rounded-2xl p-0.5 border-2 flex items-center justify-center relative shadow-lg ${
                      node.role === 'sender'
                        ? 'border-[#D4AF37] bg-[#1E1805] text-[#D4AF37]'
                        : node.role === 'relay'
                        ? 'border-amber-400 bg-amber-950/50 text-amber-300'
                        : node.role === 'recipient'
                        ? 'border-sky-400 bg-sky-950/50 text-sky-300'
                        : 'border-neutral-700 bg-neutral-900 text-neutral-400'
                    } ${isSelectedHop ? 'scale-115 ring-4 ring-[#D4AF37]/50' : ''}`}
                  >
                    <Smartphone className="w-6 h-6" />
                    <span
                      className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-black flex items-center justify-center text-[8px] font-bold ${
                        node.status === 'nearby_ble' ? 'bg-amber-400 text-black' : 'bg-sky-400 text-black'
                      }`}
                    >
                      {node.role === 'relay' ? 'R' : node.role === 'sender' ? 'É' : node.role === 'recipient' ? 'D' : '•'}
                    </span>
                  </div>

                  <span className="text-xs font-bold text-neutral-200 mt-1.5 text-center truncate max-w-full">
                    {node.name.split(' ')[0]}
                  </span>
                  <span className="text-[10px] text-neutral-400 font-mono">
                    {node.id === 'user_salman' ? 'Vous (Émetteur)' : node.role === 'relay' ? 'Relais BLE (4m)' : node.role === 'recipient' ? 'Destinataire (42m)' : `${node.distanceToMe}m`}
                  </span>
                </div>
              );
            })}

            {/* Bandeau d'action de simulation */}
            <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between bg-black/70 backdrop-blur-md p-2.5 rounded-xl border border-neutral-800">
              <div className="text-xs text-neutral-300 flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#D4AF37]" />
                <span>
                  {isSimulatingPacket
                    ? packetProgress <= 50
                      ? 'Étape 1/2 : Émetteur (Salman) ➔ Relais (Karim) en BLE 2.4GHz'
                      : 'Étape 2/2 : Relais (Karim) ➔ Destinataire (Amina) en Wi-Fi Direct'
                    : 'Prêt à tester le routage de message'}
                </span>
              </div>

              <button
                id="btn-simulate-mesh-packet"
                onClick={triggerPacketSimulation}
                disabled={isSimulatingPacket}
                className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-[#D4AF37] to-[#B38C22] text-black font-bold text-xs flex items-center gap-1.5 shadow hover:brightness-110 disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Lancer le paquet Émetteur ➔ Relais ➔ Destinataire</span>
              </button>
            </div>
          </div>

          {/* Console de journalisation */}
          <div className="bg-black/90 rounded-2xl border border-neutral-800 p-4 space-y-2">
            <div className="flex items-center justify-between text-xs pb-1 border-b border-neutral-800 text-neutral-400 font-semibold">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Journal des événements du démon de maillage
              </span>
              <span className="text-[10px] font-mono text-neutral-500">Protocole E2E v1.0</span>
            </div>
            <div className="h-28 overflow-y-auto space-y-1 font-mono text-xs text-neutral-300">
              {logMessages.map((log, i) => (
                <div key={i} className="leading-tight text-[11px]">
                  {log.includes('✅') ? (
                    <span className="text-emerald-400">{log}</span>
                  ) : log.includes('📡') ? (
                    <span className="text-sky-300">{log}</span>
                  ) : log.includes('🚀') ? (
                    <span className="text-[#D4AF37]">{log}</span>
                  ) : (
                    <span className="text-neutral-400">{log}</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Pied de page */}
        <div className="px-6 py-3 border-t border-[#242424] bg-[#161616] flex items-center justify-between text-xs text-neutral-400">
          <div className="flex items-center gap-2 text-[11px]">
            <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
            <span>Sécurité : Les paquets transitent chiffrés. Zéro accès au contenu clair pour les nœuds relais.</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-neutral-800 text-neutral-200 font-semibold hover:bg-neutral-700"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
