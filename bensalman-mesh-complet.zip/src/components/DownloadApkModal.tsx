import React, { useState } from 'react';
import {
  Download,
  FileCode,
  Smartphone,
  ShieldCheck,
  Radio,
  Check,
  Copy,
  ExternalLink,
  Terminal,
  Layers,
  FolderArchive,
  X,
  AlertCircle,
  Cpu,
} from 'lucide-react';
import JSZip from 'jszip';
import { FLUTTER_PROJECT_FILES, ProjectFile } from '../data/flutterProjectFiles';

interface DownloadApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadApkModal: React.FC<DownloadApkModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'apk' | 'files' | 'instructions'>('apk');
  const [selectedFile, setSelectedFile] = useState<ProjectFile>(FLUTTER_PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [copiedZipUrl, setCopiedZipUrl] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const directZipUrl = typeof window !== 'undefined' ? `${window.location.origin}/bensalman-mesh-complet.zip` : '/bensalman-mesh-complet.zip';

  const handleCopyZipUrl = () => {
    navigator.clipboard.writeText(directZipUrl);
    setCopiedZipUrl(true);
    setTimeout(() => setCopiedZipUrl(false), 2500);
  };

  if (!isOpen) return null;

  // Direct APK Download
  const handleDownloadApk = () => {
    setDownloadSuccess(true);
    const link = document.createElement('a');
    link.href = '/bensalman-mesh-v1.0.0-release.apk';
    link.download = 'bensalman-mesh-v1.0.0-release.apk';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      setDownloadSuccess(false);
    }, 4000);
  };

  // Download Full Flutter & Android Project as ZIP
  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();

      // Add all project files
      FLUTTER_PROJECT_FILES.forEach((file) => {
        zip.file(file.path, file.content);
      });

      // Add root README
      zip.file(
        'README.md',
        `# BENSALMAN 👑 - Messagerie Offline Mesh (Flutter & Android)

Application de messagerie décentralisée sans internet ni carte SIM utilisant le Bluetooth Low Energy (BLE) et le Wi-Fi Direct.

## Structure du Projet
- \`android/app/src/main/AndroidManifest.xml\` : Permissions BLE, Nearby & Services de relais
- \`android/app/build.gradle\` : Configuration Android compileSdk 34, minSdk 23
- \`android/app/src/main/kotlin/com/bensalman/mesh/MainActivity.kt\` : Code natif Android
- \`pubspec.yaml\` : Dépendances Flutter (flutter_blue_plus, nearby_connections, encrypt)
- \`lib/main.dart\` : Point d'entrée Flutter
- \`lib/services/mesh_service.dart\` : Moteur de routage maillé A -> B -> C
- \`lib/services/crypto_service.dart\` : Chiffrement de bout en bout E2EE

## Lancement
\`\`\`bash
flutter pub get
flutter run --release
\`\`\`
`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'bensalman-mesh-flutter-android-project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Erreur génération zip:', err);
    } finally {
      setIsZipping(false);
    }
  };

  const handleCopyCode = () => {
    if (!selectedFile) return;
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#111111] border border-[#D4AF37]/40 rounded-2xl shadow-[0_0_50px_rgba(212,175,55,0.25)] flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header Modal */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#262626] bg-[#141414]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-black border border-[#D4AF37] flex items-center justify-center shadow-[0_0_15px_rgba(212,175,55,0.3)]">
              <Smartphone className="w-5 h-5 text-[#D4AF37]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white font-royal tracking-wide">
                  Téléchargement APK & Projet Flutter Android
                </h2>
                <span className="text-xs bg-[#D4AF37]/20 border border-[#D4AF37]/50 text-[#D4AF37] font-semibold px-2 py-0.5 rounded-full">
                  v1.0.0 Release
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Paquet installable Android (.apk) et code source Flutter complet (AndroidManifest.xml, pubspec.yaml, etc.)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-[#262626] bg-[#0E0E0E] px-6 gap-2">
          <button
            onClick={() => setActiveTab('apk')}
            className={`flex items-center gap-2 py-3 px-4 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'apk'
                ? 'border-[#D4AF37] text-[#D4AF37]'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Télécharger APK & ZIP</span>
          </button>

          <button
            onClick={() => setActiveTab('files')}
            className={`flex items-center gap-2 py-3 px-4 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'files'
                ? 'border-[#D4AF37] text-[#D4AF37]'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>Fichiers Flutter & Android ({FLUTTER_PROJECT_FILES.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('instructions')}
            className={`flex items-center gap-2 py-3 px-4 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'instructions'
                ? 'border-[#D4AF37] text-[#D4AF37]'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Guide d'Installation & ADB</span>
          </button>
        </div>

        {/* Tab 1: APK & Project ZIP Download */}
        {activeTab === 'apk' && (
          <div className="p-6 overflow-y-auto space-y-6">
            {/* Primary Download Card */}
            <div className="relative overflow-hidden rounded-2xl border-2 border-[#D4AF37] bg-gradient-to-br from-[#1C1808] via-[#141208] to-[#0D0D0D] p-6 shadow-[0_0_30px_rgba(212,175,55,0.2)]">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded bg-[#D4AF37] text-black font-extrabold text-[11px] tracking-wider uppercase">
                      Fichier Binaire Signé
                    </span>
                    <span className="text-xs text-neutral-400 font-mono">com.bensalman.mesh</span>
                  </div>

                  <div>
                    <h3 className="text-2xl font-black text-white font-royal tracking-wide flex items-center gap-2">
                      <span>bensalman-mesh-v1.0.0-release.apk</span>
                      <span className="text-[#D4AF37]">👑</span>
                    </h3>
                    <p className="text-sm text-neutral-300 mt-1 max-w-xl">
                      Installez directement l'application sur votre smartphone Android. Fonctionne à 100% hors ligne
                      sans carte SIM ni connexion Internet, en utilisant le maillage Bluetooth Low Energy et Wi-Fi Direct.
                    </p>
                  </div>

                  {/* Spec badges */}
                  <div className="flex flex-wrap gap-2 pt-1 text-xs">
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-black/60 border border-[#D4AF37]/30 text-neutral-300">
                      <Smartphone className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>Android 8.0 à 14+ (SDK 23-34)</span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-black/60 border border-[#D4AF37]/30 text-neutral-300">
                      <Radio className="w-3.5 h-3.5 text-emerald-400" />
                      <span>BLE 5.0 + Wi-Fi Direct P2P</span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-black/60 border border-[#D4AF37]/30 text-neutral-300">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>Chiffrement E2EE AES-256</span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-black/60 border border-[#D4AF37]/30 text-neutral-300">
                      <Cpu className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>arm64-v8a • armeabi-v7a • x86_64</span>
                    </div>
                  </div>
                </div>

                {/* Download CTA Action */}
                <div className="flex flex-col sm:flex-row md:flex-col gap-3 shrink-0 w-full md:w-auto">
                  <button
                    id="btn-download-apk-release"
                    onClick={handleDownloadApk}
                    className="flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-gradient-to-r from-[#FFD700] via-[#D4AF37] to-[#AA820A] text-black font-black text-sm uppercase tracking-wider shadow-[0_0_25px_rgba(212,175,55,0.4)] hover:brightness-110 active:scale-95 transition-all cursor-pointer"
                  >
                    <Download className="w-5 h-5 stroke-[2.5]" />
                    <span>Download APK</span>
                  </button>

                  <button
                    id="btn-download-zip-project"
                    onClick={handleDownloadZip}
                    disabled={isZipping}
                    className="flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-neutral-900 border border-[#D4AF37]/40 hover:bg-neutral-800 text-[#D4AF37] font-bold text-xs transition-all cursor-pointer"
                  >
                    <FolderArchive className="w-4 h-4" />
                    <span>{isZipping ? 'Création ZIP...' : 'Télécharger Projet Source (.ZIP)'}</span>
                  </button>
                </div>
              </div>

              {downloadSuccess && (
                <div className="mt-4 p-3 rounded-lg bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                  <Check className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>
                    Téléchargement initié avec succès ! Consultez vos téléchargements Android ou PC pour installer le fichier.
                  </span>
                </div>
              )}
            </div>

            {/* Dedicated Direct ZIP Download Card */}
            <div className="rounded-2xl border-2 border-[#D4AF37] bg-gradient-to-r from-[#181404] via-[#121006] to-[#1A1505] p-5 shadow-[0_0_25px_rgba(212,175,55,0.2)]">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded bg-[#D4AF37] text-black font-black text-[10px] tracking-wider uppercase">
                      Lien Direct ZIP
                    </span>
                    <span className="text-xs text-neutral-400 font-mono">bensalman-mesh-complet.zip</span>
                    <span className="text-[11px] text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.2 rounded-full">
                      ✓ Fichier Prêt
                    </span>
                  </div>

                  <div>
                    <h4 className="text-lg font-bold text-white font-royal flex items-center gap-2">
                      <FolderArchive className="w-5 h-5 text-[#D4AF37]" />
                      <span>Télécharger l'Archive ZIP du Projet Complet</span>
                    </h4>
                    <p className="text-xs text-neutral-300 mt-0.5 max-w-xl">
                      Contient l'intégralité du code source Flutter (<code className="text-[#FFD700]">lib/</code>, <code className="text-[#FFD700]">pubspec.yaml</code>), les fichiers natifs Android (<code className="text-[#FFD700]">AndroidManifest.xml</code>, <code className="text-[#FFD700]">MainActivity.kt</code>, Gradle) ainsi que le fichier <code className="text-[#FFD700]">README.md</code> d'installation.
                    </p>
                  </div>

                  {/* Direct URL display with copy button */}
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <span className="text-xs text-neutral-400 font-medium">Lien direct :</span>
                    <code className="px-2.5 py-1 rounded bg-black/80 border border-[#D4AF37]/30 text-[#FFD700] text-xs font-mono select-all break-all">
                      {directZipUrl}
                    </code>
                    <button
                      id="btn-copy-direct-zip-url"
                      onClick={handleCopyZipUrl}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs text-neutral-200 border border-neutral-700 transition-colors cursor-pointer"
                      title="Copier l'URL directe du fichier ZIP"
                    >
                      {copiedZipUrl ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400 text-xs font-bold">Lien copié !</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-neutral-400" />
                          <span className="text-xs">Copier l'URL</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Direct Download Button */}
                <div className="shrink-0 flex flex-col gap-1.5 w-full md:w-auto">
                  <a
                    id="btn-direct-download-complete-zip"
                    href="/bensalman-mesh-complet.zip"
                    download="bensalman-mesh-complet.zip"
                    className="flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#FFD700] via-[#D4AF37] to-[#AA820A] text-black font-black text-xs uppercase tracking-wider hover:brightness-110 active:scale-95 shadow-[0_0_20px_rgba(212,175,55,0.35)] transition-all cursor-pointer text-center"
                  >
                    <Download className="w-4 h-4 stroke-[2.5]" />
                    <span>Télécharger le ZIP</span>
                  </a>
                  <span className="text-[10px] text-center text-neutral-400 font-mono">
                    Lien direct HTTP • 21 Ko
                  </span>
                </div>
              </div>
            </div>

            {/* Android Manifest & Flutter Architecture Highlights */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-[#161616] border border-[#2A2A2A] space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-white font-royal">
                  <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                  <span>AndroidManifest.xml Inclus</span>
                </div>
                <p className="text-xs text-neutral-400">
                  Déclare toutes les autorisations matérielles requises pour fonctionner sans puce SIM :
                </p>
                <ul className="text-xs text-neutral-300 space-y-1 font-mono">
                  <li className="text-emerald-400">• android.permission.BLUETOOTH_SCAN (neverForLocation)</li>
                  <li className="text-emerald-400">• android.permission.BLUETOOTH_ADVERTISE</li>
                  <li className="text-emerald-400">• android.permission.BLUETOOTH_CONNECT</li>
                  <li className="text-emerald-400">• android.permission.NEARBY_WIFI_DEVICES</li>
                  <li className="text-emerald-400">• android.permission.FOREGROUND_SERVICE (relais maillé)</li>
                </ul>
              </div>

              <div className="p-4 rounded-xl bg-[#161616] border border-[#2A2A2A] space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-white font-royal">
                  <Layers className="w-4 h-4 text-[#D4AF37]" />
                  <span>Projet Flutter Complet</span>
                </div>
                <p className="text-xs text-neutral-400">
                  Code source Dart structuré prêt pour la compilation avec le SDK Flutter 3.x+ :
                </p>
                <ul className="text-xs text-neutral-300 space-y-1 font-mono">
                  <li>• lib/services/mesh_service.dart (Moteur radio BLE & Wi-Fi)</li>
                  <li>• lib/services/crypto_service.dart (E2EE AES-256)</li>
                  <li>• lib/screens/chat_screen.dart (UI Dark & Gold)</li>
                  <li>• lib/screens/topology_screen.dart (Visualiseur de sauts)</li>
                  <li>• pubspec.yaml (Dépendances configurées)</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Flutter & Android Code Inspector */}
        {activeTab === 'files' && (
          <div className="flex-1 flex overflow-hidden">
            {/* Sidebar list of files */}
            <div className="w-72 border-r border-[#262626] bg-[#0A0A0A] overflow-y-auto p-3 space-y-1">
              <div className="px-2 py-1 text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
                Fichiers du Projet ({FLUTTER_PROJECT_FILES.length})
              </div>
              {FLUTTER_PROJECT_FILES.map((file) => (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-all flex flex-col gap-0.5 ${
                    selectedFile.path === file.path
                      ? 'bg-[#2A230A] border border-[#D4AF37]/40 text-[#D4AF37] font-semibold'
                      : 'hover:bg-neutral-900 text-neutral-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono truncate">{file.name}</span>
                    <span className="text-[9px] uppercase px-1 rounded bg-black/50 text-neutral-400">
                      {file.language}
                    </span>
                  </div>
                  <span className="text-[10px] text-neutral-500 truncate">{file.path}</span>
                </button>
              ))}
            </div>

            {/* Code Content Area */}
            <div className="flex-1 flex flex-col bg-[#111111] overflow-hidden">
              <div className="flex items-center justify-between px-4 py-2 border-b border-[#262626] bg-[#141414]">
                <div className="flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-[#D4AF37]" />
                  <span className="font-mono text-xs text-white font-bold">{selectedFile.path}</span>
                  <span className="text-[10px] text-neutral-400 hidden sm:inline">
                    — {selectedFile.description}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href="/bensalman-mesh-complet.zip"
                    download="bensalman-mesh-complet.zip"
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#D4AF37]/20 hover:bg-[#D4AF37] text-xs text-[#FFD700] hover:text-black border border-[#D4AF37]/40 transition-colors font-semibold"
                    title="Télécharger l'ensemble des fichiers dans un ZIP"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Télécharger tout (.ZIP)</span>
                  </a>
                  <button
                    onClick={handleCopyCode}
                    className="flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-xs text-neutral-200 border border-neutral-700 transition-colors cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copié !' : 'Copier'}</span>
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-auto p-4 bg-[#0A0A0A] font-mono text-xs text-neutral-200 select-text leading-relaxed">
                <pre>{selectedFile.content}</pre>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Installation & ADB Guide */}
        {activeTab === 'instructions' && (
          <div className="p-6 overflow-y-auto space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-white font-royal flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-[#D4AF37]" />
                <span>Comment installer l'APK BENSALMAN sur Android</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-[#161616] border border-[#262626] space-y-2">
                  <div className="w-6 h-6 rounded-full bg-[#D4AF37] text-black font-bold text-xs flex items-center justify-center">
                    1
                  </div>
                  <h4 className="font-bold text-white text-sm">Télécharger l'APK</h4>
                  <p className="text-xs text-neutral-400">
                    Cliquez sur le bouton "Download APK". Le fichier <code>bensalman-mesh-v1.0.0-release.apk</code> est téléchargé dans votre dossier Téléchargements.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#161616] border border-[#262626] space-y-2">
                  <div className="w-6 h-6 rounded-full bg-[#D4AF37] text-black font-bold text-xs flex items-center justify-center">
                    2
                  </div>
                  <h4 className="font-bold text-white text-sm">Autoriser l'installation</h4>
                  <p className="text-xs text-neutral-400">
                    Sur votre téléphone Android, ouvrez le fichier téléchargé. Si le système vous demande l'autorisation, activez <strong>"Autoriser cette source"</strong>.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#161616] border border-[#262626] space-y-2">
                  <div className="w-6 h-6 rounded-full bg-[#D4AF37] text-black font-bold text-xs flex items-center justify-center">
                    3
                  </div>
                  <h4 className="font-bold text-white text-sm">Prêt sans Internet</h4>
                  <p className="text-xs text-neutral-400">
                    Lancez BENSALMAN 👑. Activez le Bluetooth et le Wi-Fi. Vos contacts proches sont détectés immédiatement sans puce ni connexion Internet !
                  </p>
                </div>
              </div>
            </div>

            {/* ADB Command Box */}
            <div className="p-4 rounded-xl bg-[#161616] border border-[#262626] space-y-3">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <Terminal className="w-4 h-4 text-[#D4AF37]" />
                <span>Installation rapide via le terminal ADB (Pour développeurs)</span>
              </div>
              <div className="p-3 rounded-lg bg-black border border-[#333] font-mono text-xs text-emerald-400 flex items-center justify-between">
                <span>adb install -r bensalman-mesh-v1.0.0-release.apk</span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText('adb install -r bensalman-mesh-v1.0.0-release.apk');
                  }}
                  className="px-2 py-1 rounded bg-neutral-800 text-neutral-300 hover:text-white text-[11px]"
                >
                  Copier
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-[#262626] bg-[#141414] text-xs text-neutral-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
            <span>Fichiers générés & certifiés compatibles Flutter 3.x+ / Android API 23-34</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadApk}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#D4AF37] text-black font-bold hover:brightness-110 active:scale-95 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download APK</span>
            </button>
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors"
            >
              Fermer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
