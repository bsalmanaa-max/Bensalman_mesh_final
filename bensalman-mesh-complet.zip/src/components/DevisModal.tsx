import React, { useState } from 'react';
import {
  FileText,
  Clock,
  Euro,
  Layers,
  CheckCircle,
  Copy,
  Check,
  ShieldCheck,
  Cpu,
  Smartphone,
  Calendar,
  Download,
  FolderArchive,
  AlertTriangle
} from 'lucide-react';

interface DevisModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DevisModal: React.FC<DevisModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const quoteText = `=====================================================
PROPOSITION COMMERCIALE & TECHNIQUE - MVP BENSALMAN 👑
Messagerie Mobile Offline Mesh (Bluetooth + Wi-Fi Direct)
=====================================================

1. CADRE DU PROJET
-------------------
• Nom du produit : BENSALMAN 👑
• Thématique : Messagerie peer-to-peer décentralisée sans réseau ni carte SIM
• Charte graphique : Noir obsidian (#0D0D0D) et Or impérial (#D4AF37)
• Plateformes cibles : Android (APK/Play Store) et iOS (TestFlight/App Store)
• Stack recommandée : Flutter (Dart) + Google Nearby Connections / Bridgefy SDK + Firebase Auth/Firestore + Chiffrement X25519/AES-256-GCM

2. DÉLAIS DE RÉALISATION : 5 à 6 SEMAINES
------------------------------------------
• Sprint 1 (Semaines 1-2) : 
  - Architecture Flutter, intégration Firebase Auth (SMS OTP)
  - Modèle de données Firestore (profils, numéros, clés publiques)
  - UI/UX WhatsApp-like luxe Noir & Or, système de consentement mutuel d'amis
• Sprint 2 (Semaines 3-4) :
  - Intégration du moteur Mesh (Bluetooth Low Energy + Wi-Fi Direct)
  - Routage multi-sauts : transfert transparent A -> B (relais) -> C
  - Couche de chiffrement de bout en bout (E2EE) inviolable par les relais
• Sprint 3 (Semaines 5-6) :
  - Indicateur de distance (calcul RSSI / mètres) & 3 statuts temps réel
  - Support des messages texte, notes vocales et photos compressées
  - Tests en conditions réelles sur 3 terminaux sans carte SIM
  - Livraison du livrable MVP et documentation de déploiement

3. CHIFFRAGE DÉTAILLÉ DU MVP (DEVIS)
------------------------------------
• Lot 1 : Auth OTP Firebase & Gestion des profils/clés ................ 1 800 € HT
• Lot 2 : Moteur Mesh BLE/Wi-Fi Direct & Routage Relais Multi-Hop ..... 4 200 € HT
• Lot 3 : Chiffrement de bout en bout (E2E AES-256-GCM / X25519) ...... 1 600 € HT
• Lot 4 : Interface Flutter complète (WhatsApp-like Noir & Or) ........ 2 400 € HT
• Lot 5 : Tests de portée terrain multi-terminaux & Recette technique . 1 200 € HT
---------------------------------------------------------------------
TOTAL INVESTISSEMENT MVP : 11 200 € HT (Fourchette : 9 500 € – 12 500 € selon options Bridgefy/Nearby)

4. POINTS D'ATTENTION TECHNIQUES MAJEURS
-----------------------------------------
• Background iOS : iOS restreint le BLE passif en arrière-plan prolongé. Prévoir le CoreBluetooth Background Mode et une incitation à maintenir l'app active lors du rôle relais.
• Absence de carte SIM : Après inscription en Wi-Fi, la communication est 100% autonome via les ondes radio locales.

Contact développeur : Développeur Lead Mobile & Systèmes Distribués
BENSALMAN 👑 - Messagerie Offline Mesh`;

  const handleCopy = () => {
    navigator.clipboard.writeText(quoteText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#121212] border border-[#D4AF37]/50 rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-[0_0_50px_rgba(212,175,55,0.2)]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#242424] flex items-center justify-between bg-[#161616]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#1E1A0A] border border-[#D4AF37]/60 flex items-center justify-center text-[#D4AF37] shadow">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold font-royal text-[#E5E5E5]">
                  Devis & Dossier Technique MVP
                </h2>
                <span className="text-xs bg-[#D4AF37] text-black font-black px-2 py-0.5 rounded">
                  BENSALMAN 👑
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Estimation financière, calendrier d'exécution et architecture technique
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-[#D4AF37] border border-[#D4AF37]/30 transition-all"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Devis copié !' : 'Copier le devis'}</span>
            </button>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 flex items-center justify-center text-sm font-bold ml-1"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7 space-y-6">
          {/* Executive Summary Banner */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-[#1C1705] via-[#151206] to-[#0E0E0E] border border-[#D4AF37]/40 relative overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-[#D4AF37] uppercase tracking-wider">
                  Proposition Clé en Main
                </span>
                <h3 className="text-xl sm:text-2xl font-bold font-royal text-white">
                  Application Mobile BENSALMAN (MVP V1)
                </h3>
                <p className="text-xs text-neutral-300 max-w-xl">
                  Messagerie autonome offline via maillage Bluetooth Low Energy & Wi-Fi Direct, sans internet et sans carte SIM active, avec inscription en ligne unique et consentement mutuel.
                </p>
              </div>

              <div className="sm:text-right shrink-0 bg-black/40 p-3.5 rounded-xl border border-[#D4AF37]/30">
                <div className="text-xs text-neutral-400">Budget Global MVP Estimé</div>
                <div className="text-2xl font-bold font-royal gold-text-gradient">
                  11 200 € HT
                </div>
                <div className="text-[11px] text-emerald-400 font-medium">Délai : 5 à 6 semaines</div>
              </div>
            </div>
          </div>

          {/* 3 Pillars Breakdown: Delais, Budget, Stack */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Pillar 1: Delais */}
            <div className="p-4 rounded-2xl bg-[#171717] border border-neutral-800 space-y-3">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <Clock className="w-4 h-4" />
                <span>Délai Total : 5 à 6 Semaines</span>
              </div>
              <ul className="space-y-2 text-xs text-neutral-300">
                <li className="flex items-start gap-2">
                  <span className="w-4 h-4 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">1</span>
                  <div>
                    <strong className="text-white">Semaines 1-2 :</strong> Socle Flutter, Auth Firebase SMS OTP, UI WhatsApp Noir & Or, Consentement.
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-4 h-4 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">2</span>
                  <div>
                    <strong className="text-white">Semaines 3-4 :</strong> Moteur Mesh BLE/Wi-Fi Direct, relais multi-sauts A➔B➔C, Chiffrement E2E.
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-4 h-4 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">3</span>
                  <div>
                    <strong className="text-white">Semaines 5-6 :</strong> Distance RSSI, audio/images offline, tests terrain sans SIM & livraison.
                  </div>
                </li>
              </ul>
            </div>

            {/* Pillar 2: Stack Technique */}
            <div className="p-4 rounded-2xl bg-[#171717] border border-neutral-800 space-y-3">
              <div className="flex items-center gap-2 text-sky-400 font-bold text-sm">
                <Cpu className="w-4 h-4" />
                <span>Stack Technique Prévue</span>
              </div>
              <ul className="space-y-2 text-xs text-neutral-300">
                <li className="flex items-center gap-2">
                  <Smartphone className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                  <span><strong>Framework :</strong> Flutter (Android & iOS)</span>
                </li>
                <li className="flex items-center gap-2">
                  <Layers className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                  <span><strong>Mesh :</strong> Google Nearby / Bridgefy SDK</span>
                </li>
                <li className="flex items-center gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                  <span><strong>Crypto :</strong> AES-256-GCM + X25519</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                  <span><strong>Online Backend :</strong> Firebase Auth & Firestore</span>
                </li>
              </ul>
            </div>

            {/* Pillar 3: Livrables */}
            <div className="p-4 rounded-2xl bg-[#171717] border border-neutral-800 space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <CheckCircle className="w-4 h-4" />
                <span>Livrables Clés</span>
              </div>
              <ul className="space-y-2 text-xs text-neutral-300">
                <li>• Code source complet du projet Flutter structuré (Clean Architecture)</li>
                <li>• Fichier d'installation Android (.APK prêt au test)</li>
                <li>• Build iOS TestFlight pour tests internes</li>
                <li>• Documentation technique & guide d'intégration des clés de chiffrement</li>
              </ul>
            </div>
          </div>

          {/* Detailed Financial Breakdown Table */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Euro className="w-4 h-4 text-[#D4AF37]" />
              <span>Chiffrage Détaillé par Module (Lots Fonctionnels)</span>
            </h3>

            <div className="overflow-hidden rounded-2xl border border-neutral-800 bg-[#161616]">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#1C1C1C] border-b border-neutral-800 text-neutral-400 font-semibold">
                  <tr>
                    <th className="p-3">Module Fonctionnel</th>
                    <th className="p-3 hidden sm:table-cell">Spécifications Incluses</th>
                    <th className="p-3 text-right">Montant HT</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800 text-neutral-200">
                  <tr>
                    <td className="p-3 font-semibold text-white">
                      Lot 1 : Authentification OTP & Backend Firebase
                    </td>
                    <td className="p-3 text-neutral-400 hidden sm:table-cell">
                      Vérification SMS internationale, création compte, stockage sécurisé clés publiques Firestore
                    </td>
                    <td className="p-3 text-right font-mono text-[#D4AF37] font-bold">1 800 €</td>
                  </tr>

                  <tr>
                    <td className="p-3 font-semibold text-white">
                      Lot 2 : Cœur Réseau Mesh & Routage Relais Multi-Hop
                    </td>
                    <td className="p-3 text-neutral-400 hidden sm:table-cell">
                      Découverte BLE, Wi-Fi Direct, protocole de routage (A ➔ B [relais] ➔ C), gestion déconnexions
                    </td>
                    <td className="p-3 text-right font-mono text-[#D4AF37] font-bold">4 200 €</td>
                  </tr>

                  <tr>
                    <td className="p-3 font-semibold text-white">
                      Lot 3 : Chiffrement de Bout en Bout (E2EE)
                    </td>
                    <td className="p-3 text-neutral-400 hidden sm:table-cell">
                      Échange de clés X25519, chiffrement symétrique AES-256-GCM, empreinte de sécurité anti-espion
                    </td>
                    <td className="p-3 text-right font-mono text-[#D4AF37] font-bold">1 600 €</td>
                  </tr>

                  <tr>
                    <td className="p-3 font-semibold text-white">
                      Lot 4 : Interface Mobile WhatsApp-like Noir & Or
                    </td>
                    <td className="p-3 text-neutral-400 hidden sm:table-cell">
                      Charte BENSALMAN (#0D0D0D & #D4AF37), 3 statuts, indicateur distance, notes vocales & photos
                    </td>
                    <td className="p-3 text-right font-mono text-[#D4AF37] font-bold">2 400 €</td>
                  </tr>

                  <tr>
                    <td className="p-3 font-semibold text-white">
                      Lot 5 : Recette Matérielle & Tests de Portée sans SIM
                    </td>
                    <td className="p-3 text-neutral-400 hidden sm:table-cell">
                      Tests terrain (3 smartphones physiques sans réseau), validation relais, livraison APK/TestFlight
                    </td>
                    <td className="p-3 text-right font-mono text-[#D4AF37] font-bold">1 200 €</td>
                  </tr>
                </tbody>
                <tfoot className="bg-[#1C1705] border-t border-[#D4AF37]/30 text-xs">
                  <tr>
                    <td colSpan={2} className="p-3.5 font-bold text-white text-sm">
                      Total Devis Estimé (Développement & Recette Complète)
                    </td>
                    <td className="p-3.5 text-right font-mono text-base font-extrabold gold-text-gradient">
                      11 200 € HT
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Expert Technical Advice & Feasibility Box */}
          <div className="p-4 rounded-2xl bg-[#141208] border border-[#D4AF37]/30 space-y-2 text-xs text-neutral-300">
            <div className="flex items-center gap-2 text-[#D4AF37] font-bold">
              <AlertTriangle className="w-4 h-4" />
              <span>Conseils de faisabilité pour BENSALMAN :</span>
            </div>
            <p className="leading-relaxed">
              <strong>1. Autonomie sans puce :</strong> Une fois l'étape 1 d'authentification réalisée, l'appareil conserve ses clés cryptographiques dans le Secure Storage local et peut fonctionner indéfiniment sans carte SIM.
            </p>
            <p className="leading-relaxed">
              <strong>2. Background iOS :</strong> Apple impose des règles strictes pour le Bluetooth en arrière-plan prolongé. Nous recommandons de configurer les autorisations <em>bluetooth-central</em> et <em>bluetooth-peripheral</em> avec le mécanisme de <em>State Restoration</em> de CoreBluetooth pour maximiser la disponibilité des relais.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#242424] bg-[#161616] flex items-center justify-between">
          <span className="text-xs text-neutral-400 font-mono">
            Validité de l'offre : 30 jours
          </span>

          <div className="flex items-center gap-2">
            <a
              id="devis-direct-download-zip"
              href="/bensalman-mesh-complet.zip"
              download="bensalman-mesh-complet.zip"
              className="px-3.5 py-2 rounded-xl bg-[#1C1705] border border-[#D4AF37]/50 hover:bg-[#D4AF37] hover:text-black text-[#FFD700] text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
              title="Télécharger l'archive ZIP du projet complet"
            >
              <FolderArchive className="w-3.5 h-3.5" />
              <span>Projet .ZIP</span>
            </a>

            <button
              onClick={handleCopy}
              className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1.5"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Copier le texte du devis</span>
            </button>

            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-[#D4AF37] text-black font-bold text-xs hover:brightness-110"
            >
              Fermer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
