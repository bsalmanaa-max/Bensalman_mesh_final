import React, { useState } from 'react';
import { Phone, KeyRound, ShieldCheck, CheckCircle2, Smartphone, ArrowRight, Lock } from 'lucide-react';
import { UserProfile } from '../types';
import { generateKeyPair } from '../utils/crypto';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onUpdateUser: (updated: Partial<UserProfile>) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  user,
  onUpdateUser,
}) => {
  const [step, setStep] = useState<'phone' | 'otp' | 'profile' | 'success'>('phone');
  const [phoneNumber, setPhoneNumber] = useState(user.phone || '+33 6 12 34 56 78');
  const [otpCode, setOtpCode] = useState('');
  const [userName, setUserName] = useState(user.name || 'Salman Bah');
  const [generatedKey, setGeneratedKey] = useState(user.publicKey);
  const [isVerifying, setIsVerifying] = useState(false);

  if (!isOpen) return null;

  const handleRequestOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setStep('otp');
      setOtpCode('784291'); // simulated SMS received
    }, 1000);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      const keys = generateKeyPair();
      setGeneratedKey(keys.publicKey);
      setStep('profile');
    }, 900);
  };

  const handleCompleteRegistration = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      name: userName,
      phone: phoneNumber,
      publicKey: generatedKey,
      isRegistered: true,
    });
    setStep('success');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#121212] border border-[#D4AF37]/40 rounded-3xl max-w-md w-full overflow-hidden shadow-[0_0_40px_rgba(212,175,55,0.15)]">
        {/* Header */}
        <div className="px-6 py-5 border-b border-[#242424] text-center bg-[#161616] relative">
          <div className="w-12 h-12 rounded-2xl bg-black border border-[#D4AF37]/50 mx-auto flex items-center justify-center shadow-lg mb-2">
            <span className="font-royal text-xl font-bold text-[#D4AF37]">B</span>
          </div>
          <h2 className="text-lg font-bold font-royal text-[#E5E5E5] flex items-center justify-center gap-1.5">
            <span>BENSALMAN 👑</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Inscription Unique ONLINE (Firebase Auth + Clé E2E)
          </p>

          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-neutral-400 hover:text-white text-sm"
          >
            ✕
          </button>
        </div>

        <div className="p-6">
          {/* Step 1: Phone input */}
          {step === 'phone' && (
            <form onSubmit={handleRequestOtp} className="space-y-4">
              <div className="text-center space-y-1 mb-4">
                <h3 className="text-sm font-bold text-white">Étape 1/3 : Numéro de mobile</h3>
                <p className="text-xs text-neutral-400">
                  Obligatoire une seule fois avec connexion pour valider votre numéro et recevoir votre clé cryptographique.
                </p>
              </div>

              <div>
                <label className="text-xs text-neutral-400 block mb-1.5">
                  Numéro de téléphone (Format International)
                </label>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-2.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs font-mono text-[#D4AF37]">
                    🌐
                  </span>
                  <input
                    type="tel"
                    required
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="+33 6 12 34 56 78"
                    className="flex-1 bg-[#1A1A1A] border border-neutral-700 rounded-xl px-4 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              <div className="p-3 bg-[#181507] border border-[#D4AF37]/30 rounded-xl text-xs text-amber-200/90 leading-relaxed flex items-start gap-2">
                <Lock className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>
                  Après cette validation, l'application fonctionne entièrement <strong>SANS carte SIM active</strong> et <strong>SANS réseau cellulaire</strong> via Mesh Bluetooth.
                </span>
              </div>

              <button
                type="submit"
                disabled={isVerifying}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B38C22] text-black font-bold text-sm hover:brightness-110 shadow disabled:opacity-50 transition-all flex items-center justify-center gap-2"
              >
                {isVerifying ? (
                  <span>Envoi du SMS Firebase...</span>
                ) : (
                  <>
                    <span>Recevoir le code OTP (SMS)</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}

          {/* Step 2: OTP verification */}
          {step === 'otp' && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="text-center space-y-1 mb-4">
                <h3 className="text-sm font-bold text-white">Étape 2/3 : Code de validation SMS</h3>
                <p className="text-xs text-neutral-400">
                  Code à 6 chiffres envoyé au <span className="font-mono text-[#D4AF37]">{phoneNumber}</span>
                </p>
              </div>

              <div className="space-y-2">
                <input
                  type="text"
                  maxLength={6}
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="784291"
                  className="w-full bg-[#1A1A1A] border border-[#D4AF37]/50 rounded-xl px-4 py-3 text-center text-xl tracking-[0.5em] font-mono text-[#D4AF37] font-bold focus:outline-none"
                />
                <div className="text-[11px] text-center text-neutral-500">
                  Simulation : code reçu automatiquement (784291)
                </div>
              </div>

              <button
                type="submit"
                disabled={isVerifying}
                className="w-full py-3 rounded-xl bg-[#D4AF37] text-black font-bold text-sm hover:brightness-110 shadow flex items-center justify-center gap-2"
              >
                {isVerifying ? (
                  <span>Validation Firebase Auth...</span>
                ) : (
                  <>
                    <KeyRound className="w-4 h-4" />
                    <span>Valider et Générer la Clé E2E</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* Step 3: Profile and E2E Key */}
          {step === 'profile' && (
            <form onSubmit={handleCompleteRegistration} className="space-y-4">
              <div className="text-center space-y-1 mb-3">
                <h3 className="text-sm font-bold text-white">Étape 3/3 : Finalisation Profil & Clé</h3>
                <p className="text-xs text-neutral-400">
                  Votre identité chiffrée sur le réseau maillé BENSALMAN
                </p>
              </div>

              <div>
                <label className="text-xs text-neutral-400 block mb-1">Nom / Pseudonyme</label>
                <input
                  type="text"
                  required
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="w-full bg-[#1A1A1A] border border-neutral-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div className="p-3 bg-black rounded-xl border border-neutral-800 space-y-1.5">
                <div className="text-[11px] text-[#D4AF37] font-semibold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Clé Publique X25519 Générée (Stockage sécurisé)</span>
                </div>
                <div className="font-mono text-[10px] text-neutral-400 break-all bg-neutral-900 p-2 rounded border border-neutral-800">
                  {generatedKey}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#D4AF37] to-[#B38C22] text-black font-bold text-sm hover:brightness-110 shadow"
              >
                Activer la Messagerie Offline
              </button>
            </form>
          )}

          {/* Step 4: Success confirmation */}
          {step === 'success' && (
            <div className="text-center space-y-4 py-2">
              <div className="w-14 h-14 rounded-full bg-[#1A1605] border border-[#D4AF37] text-[#D4AF37] mx-auto flex items-center justify-center shadow-[0_0_20px_rgba(212,175,55,0.3)]">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h3 className="text-base font-bold text-white">Inscription Validée !</h3>
                <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                  Votre terminal est maintenant prêt pour communiquer en Mesh Bluetooth Low Energy et Wi-Fi Direct avec vos amis.
                </p>
              </div>

              <button
                onClick={onClose}
                className="w-full py-2.5 rounded-xl bg-[#D4AF37] text-black font-bold text-xs hover:brightness-110"
              >
                Accéder à mes discussions
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
