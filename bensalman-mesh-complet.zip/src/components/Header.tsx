import React from 'react';
import { Radio, Wifi, WifiOff, ShieldCheck, Share2, FileText, UserPlus, Sliders, Battery, Download, FolderArchive } from 'lucide-react';
import { UserProfile, ConnectivityStatus } from '../types';

interface HeaderProps {
  user: UserProfile;
  activeTab: 'chats' | 'friends' | 'mesh';
  setActiveTab: (tab: 'chats' | 'friends' | 'mesh') => void;
  isMeshActive: boolean;
  setIsMeshActive: (val: boolean) => void;
  onOpenMeshModal: () => void;
  onOpenFriendsModal: () => void;
  onOpenDevisModal: () => void;
  onOpenSettingsModal: () => void;
  onOpenDownloadApkModal: () => void;
  pendingInvitationsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  activeTab,
  setActiveTab,
  isMeshActive,
  setIsMeshActive,
  onOpenMeshModal,
  onOpenFriendsModal,
  onOpenDevisModal,
  onOpenSettingsModal,
  onOpenDownloadApkModal,
  pendingInvitationsCount,
}) => {
  return (
    <header className="bg-[#111111] border-b border-[#262626] px-4 py-3 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Marque & Logo */}
        <div className="flex items-center gap-3">
          <div className="relative group cursor-pointer" onClick={() => setActiveTab('chats')}>
            <div className="w-10 h-10 rounded-xl bg-black border border-[#D4AF37]/50 flex items-center justify-center overflow-hidden shadow-[0_0_15px_rgba(212,175,55,0.25)]">
              <img 
                src="/src/assets/images/bensalman_logo_1789618057992.jpg" 
                alt="Logo BENSALMAN" 
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <span className="font-royal text-lg font-bold text-[#D4AF37] leading-none absolute">B</span>
            </div>
            <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#111] rounded-full" title="Réseau maillé actif" />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-royal text-lg font-extrabold tracking-wider gold-text-gradient">
                BENSALMAN
              </span>
              <span className="text-[#D4AF37] text-sm">👑</span>
              <span className="text-[10px] uppercase tracking-widest px-1.5 py-0.5 rounded bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] font-semibold ml-1">
                Maillage v1.0
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-neutral-400">
              <span className="flex items-center gap-1 text-emerald-400 font-medium">
                <Radio className="w-3 h-3 animate-pulse" />
                {isMeshActive ? 'Maillage BLE + Wi-Fi Direct' : 'Mode Veille'}
              </span>
              <span className="text-neutral-600">•</span>
              <span className="flex items-center gap-1 text-neutral-400">
                <ShieldCheck className="w-3 h-3 text-[#D4AF37]" />
                Chiffrement de bout en bout
              </span>
            </div>
          </div>
        </div>

        {/* Boutons d'action & Menu */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Bascule rapide du mode maillage */}
          <button
            id="toggle-mesh-mode"
            onClick={() => setIsMeshActive(!isMeshActive)}
            className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
              isMeshActive
                ? 'bg-[#1E1905] border-[#D4AF37]/40 text-[#D4AF37]'
                : 'bg-neutral-900 border-neutral-700 text-neutral-400'
            }`}
            title="Activer ou désactiver le réseau maillé sans fil"
          >
            {isMeshActive ? <Radio className="w-3.5 h-3.5 text-[#D4AF37]" /> : <WifiOff className="w-3.5 h-3.5 text-neutral-500" />}
            <span>{isMeshActive ? 'Maillage Actif' : 'Maillage Suspendu'}</span>
          </button>

          {/* Visualiseur de topologie maillée */}
          <button
            id="open-mesh-topology"
            onClick={onOpenMeshModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700 hover:border-[#D4AF37]/50 transition-colors"
            title="Voir la carte du réseau maillé et les relais A -> B -> C"
          >
            <Share2 className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="hidden md:inline">Topologie Maillage</span>
          </button>

          {/* Demandes d'amis & Consentement mutuel */}
          <button
            id="open-friends-modal"
            onClick={onOpenFriendsModal}
            className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700 hover:border-[#D4AF37]/50 transition-colors"
            title="Ajout d'amis & Consentement Mutuel"
          >
            <UserPlus className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="hidden md:inline">Amis</span>
            {pendingInvitationsCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-[#D4AF37] text-black text-[10px] font-black flex items-center justify-center shadow-md">
                {pendingInvitationsCount}
              </span>
            )}
          </button>

          {/* DOWNLOAD APK */}
          <button
            id="open-download-apk-modal"
            onClick={onOpenDownloadApkModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-[#1F1905] border border-[#D4AF37] text-[#FFD700] hover:bg-[#D4AF37] hover:text-black shadow-[0_0_15px_rgba(212,175,55,0.25)] transition-all cursor-pointer"
            title="Télécharger l'APK Android et voir les fichiers Flutter"
          >
            <Download className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Download APK</span>
            <span className="text-[10px] bg-[#D4AF37]/20 border border-[#D4AF37]/40 px-1 py-0.2 rounded font-mono">v1.0</span>
          </button>

          {/* LIEN DIRECT ZIP PROJET COMPLET */}
          <a
            id="direct-download-project-zip-header"
            href="/bensalman-mesh-complet.zip"
            download="bensalman-mesh-complet.zip"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-[#121212] border border-[#D4AF37]/50 text-[#D4AF37] hover:bg-[#D4AF37] hover:text-black hover:border-[#D4AF37] shadow-[0_0_10px_rgba(212,175,55,0.15)] transition-all cursor-pointer"
            title="Lien direct : Télécharger l'archive ZIP du projet complet (Android & Flutter)"
          >
            <FolderArchive className="w-3.5 h-3.5" />
            <span>Projet .ZIP</span>
            <span className="text-[10px] bg-[#D4AF37]/20 border border-[#D4AF37]/30 px-1 py-0.2 rounded font-mono">Direct</span>
          </a>

          {/* DEVIS & DÉLAI MVP */}
          <button
            id="open-devis-modal"
            onClick={onOpenDevisModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold bg-gradient-to-r from-[#D4AF37] to-[#B38C22] text-black shadow-[0_0_15px_rgba(212,175,55,0.3)] hover:brightness-110 active:scale-95 transition-all"
            title="Consulter le Devis & Délais techniques pour le MVP"
          >
            <FileText className="w-3.5 h-3.5 text-black" />
            <span className="hidden sm:inline">Devis MVP</span>
            <span className="text-[10px] bg-black/20 px-1 py-0.2 rounded font-mono">👑</span>
          </button>

          {/* Paramètres & profil utilisateur */}
          <button
            id="open-settings-modal"
            onClick={onOpenSettingsModal}
            className="p-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700"
            title="Paramètres du compte et clés de chiffrement"
          >
            <Sliders className="w-4 h-4 text-neutral-400 hover:text-[#D4AF37]" />
          </button>
        </div>
      </div>
    </header>
  );
};
