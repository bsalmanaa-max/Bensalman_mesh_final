package com.bensalman.mesh

import android.content.Context
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.bensalman.mesh/radio"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "checkMeshHardwareSupport" -> {
                    val packageManager = context.packageManager
                    val hasBle = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_BLUETOOTH_LE)
                    val hasWifiDirect = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_WIFI_DIRECT)
                    
                    val capabilities = mapOf(
                        "bleSupported" to hasBle,
                        "wifiDirectSupported" to hasWifiDirect,
                        "androidVersion" to Build.VERSION.SDK_INT,
                        "deviceModel" to Build.MODEL
                    )
                    result.success(capabilities)
                }
                "startMeshForegroundService" -> {
                    // Start low-power mesh listener service
                    result.success(true)
                }
                "stopMeshForegroundService" -> {
                    result.success(true)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }
}
